export type PlatformId =
  | "instagram"
  | "x"
  | "tiktok"
  | "linkedin"
  | "facebook"
  | "youtube"
  | "pinterest"
  | "whatsapp";

export const PLATFORMS: Record<PlatformId, { name: string; color: string; tint: string }> = {
  instagram: { name: "Instagram", color: "#ff5c8a", tint: "rgba(255,92,138,0.14)" },
  x: { name: "X (Twitter)", color: "#c9d4e3", tint: "rgba(201,212,227,0.12)" },
  tiktok: { name: "TikTok", color: "#35e2d4", tint: "rgba(53,226,212,0.13)" },
  linkedin: { name: "LinkedIn", color: "#5aa7f0", tint: "rgba(90,167,240,0.14)" },
  facebook: { name: "Facebook", color: "#6f9ff0", tint: "rgba(111,159,240,0.14)" },
  youtube: { name: "YouTube", color: "#ff5a4e", tint: "rgba(255,90,78,0.14)" },
  pinterest: { name: "Pinterest", color: "#ff6675", tint: "rgba(255,102,117,0.14)" },
  whatsapp: { name: "WhatsApp", color: "#43d97b", tint: "rgba(67,217,123,0.13)" },
};

export interface Account {
  id: string;
  platform: PlatformId;
  handle: string;
  followers: number;
  growth: number;
  status: "online" | "attention" | "offline";
  statusNote?: string;
  lastSync: string;
  autos: number;
}

export interface ScheduledPost {
  id: string;
  day: number; // 0 = Seg ... 6 = Dom
  time: string; // "19:00"
  platforms: PlatformId[];
  text: string;
  media: "imagem" | "vídeo" | "carrossel" | "link" | null;
  status: "agendada" | "publicada" | "rascunho";
  reach?: number;
  engagement?: number;
}

export interface Automation {
  id: string;
  name: string;
  trigger: string;
  action: string;
  platforms: PlatformId[];
  active: boolean;
  runs: number;
  lastRun: string;
}

export interface Mention {
  id: string;
  platform: PlatformId;
  author: string;
  handle: string;
  text: string;
  time: string;
  sentiment: "positivo" | "neutro" | "negativo";
  unread: boolean;
  replied?: string;
}

export interface FeedEvent {
  id: number;
  icon: "heart" | "user" | "comment" | "zap" | "trend" | "share";
  text: string;
  ts: number;
  platform?: PlatformId;
}

export interface RunLog {
  id: number;
  time: string;
  text: string;
  status: "ok" | "warn";
}

export const WEEK = [
  { d: "Seg", n: 9 },
  { d: "Ter", n: 10 },
  { d: "Qua", n: 11 },
  { d: "Qui", n: 12 },
  { d: "Sex", n: 13 },
  { d: "Sáb", n: 14 },
  { d: "Dom", n: 15 },
];

export const ACCOUNTS: Account[] = [
  { id: "a1", platform: "instagram", handle: "@lume.studio", followers: 64200, growth: 3.1, status: "online", lastSync: "há 2 min", autos: 4 },
  { id: "a2", platform: "tiktok", handle: "@lumestudio", followers: 128900, growth: 5.4, status: "online", lastSync: "há 5 min", autos: 2 },
  { id: "a3", platform: "x", handle: "@lumestudio", followers: 18400, growth: 1.2, status: "online", lastSync: "há 1 min", autos: 2 },
  { id: "a4", platform: "linkedin", handle: "Lume Studio", followers: 9800, growth: 0.8, status: "online", lastSync: "há 8 min", autos: 1 },
  { id: "a5", platform: "facebook", handle: "Lume Studio", followers: 22100, growth: -0.4, status: "attention", statusNote: "Token expira em 3 dias", lastSync: "há 6 h", autos: 1 },
  { id: "a6", platform: "youtube", handle: "Lume Studio", followers: 41700, growth: 2.2, status: "online", lastSync: "há 12 min", autos: 1 },
];

export const POSTS: ScheduledPost[] = [
  { id: "p1", day: 0, time: "09:30", platforms: ["instagram"], text: "Bom dia, segunda! A semana começa com mesa nova no estúdio ☕", media: "imagem", status: "publicada", reach: 48200, engagement: 4210 },
  { id: "p2", day: 0, time: "12:00", platforms: ["x"], text: "Thread: 5 aprendizados de 2 anos publicando conteúdo todos os dias 🧵", media: null, status: "publicada", reach: 12900, engagement: 890 },
  { id: "p3", day: 1, time: "19:00", platforms: ["instagram", "tiktok"], text: "Antes e depois do rebrand da @flor.decor — carrossel completo 🎨", media: "carrossel", status: "agendada" },
  { id: "p4", day: 2, time: "08:30", platforms: ["linkedin"], text: "Artigo: como estruturamos um calendário editorial que roda sozinho", media: "link", status: "agendada" },
  { id: "p5", day: 2, time: "15:00", platforms: ["instagram"], text: "Enquete nos stories: qual cor vai para a próxima coleção?", media: null, status: "publicada", reach: 31400, engagement: 2860 },
  { id: "p6", day: 3, time: "12:30", platforms: ["instagram"], text: "Reel: nosso processo de embalagem em 15 segundos ⏱", media: "vídeo", status: "agendada" },
  { id: "p7", day: 3, time: "19:00", platforms: ["youtube"], text: "Estreia: tour completo pelo estúdio novo", media: "vídeo", status: "agendada" },
  { id: "p8", day: 4, time: "10:00", platforms: ["facebook"], text: "Álbum: os melhores registros do evento de sábado", media: "imagem", status: "agendada" },
  { id: "p9", day: 4, time: "17:45", platforms: ["x"], text: "Bastidores em tempo real, direto do set 📸", media: null, status: "agendada" },
  { id: "p10", day: 5, time: "11:00", platforms: ["tiktok"], text: "Nossa versão da trend da semana ✨", media: "vídeo", status: "agendada" },
  { id: "p11", day: 6, time: "18:30", platforms: ["instagram"], text: "Prévia da coleção de inverno (aguardando aprovação)", media: "carrossel", status: "rascunho" },
  { id: "p12", day: 6, time: "20:00", platforms: ["x", "linkedin"], text: "Resumo da semana em 6 pontos — o que funcionou e o que não funcionou", media: null, status: "agendada" },
];

export const AUTOMATIONS: Automation[] = [
  { id: "r1", name: "Boas-vindas a novos seguidores", trigger: "Novo seguidor no Instagram", action: "Enviar DM de boas-vindas com cupom de 10%", platforms: ["instagram"], active: true, runs: 1284, lastRun: "há 12 min" },
  { id: "r2", name: "Dúvidas de preço", trigger: "Comentário contém “preço”, “valor” ou “quanto”", action: "Responder com a tabela de preços atualizada", platforms: ["instagram", "x", "facebook"], active: true, runs: 486, lastRun: "há 38 min" },
  { id: "r3", name: "Republicar UGC", trigger: "Marcação da marca em post ou story", action: "Adicionar à fila de republicação com crédito ao autor", platforms: ["instagram", "tiktok"], active: true, runs: 197, lastRun: "há 2 h" },
  { id: "r4", name: "Conteúdo evergreen", trigger: "Queda de engajamento por mais de 24 h", action: "Republicar o melhor post do mês no horário de pico", platforms: ["instagram", "linkedin"], active: true, runs: 63, lastRun: "ontem, 19:02" },
  { id: "r5", name: "Relatório semanal", trigger: "Toda segunda-feira às 08:00", action: "Enviar resumo de métricas por e-mail para a equipe", platforms: ["instagram", "x", "tiktok", "linkedin"], active: false, runs: 24, lastRun: "seg, 08:00" },
  { id: "r6", name: "Resgate de menções", trigger: "Menção sem resposta há mais de 2 h", action: "Mover para o topo da caixa de entrada e notificar", platforms: ["x", "facebook"], active: true, runs: 342, lastRun: "há 1 h" },
];

export const RUN_LOG: RunLog[] = [
  { id: 1, time: "11:48", text: "Boas-vindas enviada para @ana.souza (Instagram)", status: "ok" },
  { id: 2, time: "11:31", text: "Tabela de preços enviada em resposta a @marcos_v (X)", status: "ok" },
  { id: 3, time: "10:57", text: "UGC de @ju.crafts adicionado à fila de republicação", status: "ok" },
  { id: 4, time: "10:12", text: "Facebook: token perto de expirar — renovação necessária", status: "warn" },
  { id: 5, time: "09:44", text: "Menção de @cafezinhopod movida para o topo da caixa de entrada", status: "ok" },
  { id: 6, time: "09:02", text: "Evergreen republicado no melhor horário (19h) — agendado", status: "ok" },
];

export const MENTIONS: Mention[] = [
  { id: "m1", platform: "facebook", author: "Renata Alves", handle: "@renata.alvs", text: "Enviei uma mensagem há 3 dias sobre meu pedido e ainda não tive retorno. Preciso de uma posição, por favor.", time: "há 25 min", sentiment: "negativo", unread: true },
  { id: "m2", platform: "x", author: "Marcos Vieira", handle: "@marcos_v", text: "Qual o valor do plano anual? Não achei essa informação no site 🤔", time: "há 42 min", sentiment: "neutro", unread: true },
  { id: "m3", platform: "instagram", author: "Juliana Prado", handle: "@ju.crafts", text: "Amei a coleção nova!! Já garanti a minha peça favorita 😍 Parabéns pelo trabalho.", time: "há 1 h", sentiment: "positivo", unread: true },
  { id: "m4", platform: "tiktok", author: "Pedro Lima", handle: "@pedrolima", text: "Esse reel de embalagem é satisfatório demais, poderiam fazer toda semana", time: "há 2 h", sentiment: "positivo", unread: false },
  { id: "m5", platform: "linkedin", author: "Carla Mendes", handle: "Carla Mendes", text: "Excelente artigo sobre calendário editorial. Vocês usam alguma ferramenta para aprovações internas?", time: "há 3 h", sentiment: "neutro", unread: false },
  { id: "m6", platform: "instagram", author: "Diego Santos", handle: "@digo.snts", text: "O pedido chegou com a embalagem errada. Como faço para trocar?", time: "há 4 h", sentiment: "negativo", unread: false },
  { id: "m7", platform: "x", author: "Cafézinho Pod", handle: "@cafezinhopod", text: "Citamos vocês no episódio de hoje! A parte sobre automação de redes é ouro 🎧", time: "há 5 h", sentiment: "positivo", unread: false },
];

export const EVENT_POOL: Omit<FeedEvent, "id" | "ts">[] = [
  { icon: "user", text: "Novo seguidor: @ana.souza no Instagram", platform: "instagram" },
  { icon: "heart", text: "Post das 09h30 passou de 4,2 mil curtidas", platform: "instagram" },
  { icon: "comment", text: "@pedrolima comentou no reel de embalagem", platform: "tiktok" },
  { icon: "zap", text: "Automação respondeu 3 dúvidas de preço", platform: "x" },
  { icon: "trend", text: "Alcance subiu 18% em relação à média", platform: "instagram" },
  { icon: "share", text: "+18 compartilhamentos no TikTok nas últimas 2 h", platform: "tiktok" },
  { icon: "user", text: "Menção em story de @cafezinhopod detectada", platform: "x" },
  { icon: "heart", text: "Vídeo do YouTube ganhou 214 visualizações", platform: "youtube" },
  { icon: "zap", text: "UGC de @ju.crafts aprovado para republicação", platform: "instagram" },
  { icon: "comment", text: "Nova avaliação 5★ na página do Facebook", platform: "facebook" },
  { icon: "trend", text: "LinkedIn: artigo entrou no top 10 do perfil", platform: "linkedin" },
  { icon: "user", text: "4 novos inscritos no canal do YouTube", platform: "youtube" },
  { icon: "share", text: "Thread da semana republicada por @estudio.na", platform: "x" },
  { icon: "heart", text: "Story da enquete alcançou 6,8 mil contas", platform: "instagram" },
];

export const HASHTAGS = [
  { tag: "#bastidores", vol: "2,1 mil posts" },
  { tag: "#smallbusiness", vol: "18,4 mil posts" },
  { tag: "#reelsbrasil", vol: "9,7 mil posts" },
  { tag: "#designautoral", vol: "1,3 mil posts" },
  { tag: "#dicasdedia", vol: "4,5 mil posts" },
  { tag: "#empreendedorismo", vol: "22,9 mil posts" },
  { tag: "#ugc", vol: "6,2 mil posts" },
  { tag: "#calendariodeconteudo", vol: "890 posts" },
];

export const AI_CAPTIONS = [
  "Bastidores de hoje: cada detalhe passa por aqui antes de chegar até você ✨ #bastidores #lumestudio",
  "3 erros que todo mundo comete ao começar — e como a gente resolve cada um 👇 Salva esse post!",
  "A novidade que vocês pediram chegou. Corre no link da bio antes que acabe 🔗",
  "Segunda-feira pede plano: essa é a nossa rotina de conteúdo em 30 segundos ⏱",
  "Feito à mão, postado com estratégia. Conheça o processo por trás da peça 💛",
];

export const AI_REPLIES: Record<Mention["sentiment"], string> = {
  negativo: "Oi! Sentimos muito pelo ocorrido — isso não reflete o nosso padrão. Acabei de escalar seu caso com prioridade para a equipe responsável. Pode me confirmar o número do pedido por DM? Vamos resolver ainda hoje. 🙏",
  neutro: "Oi! Obrigado pela pergunta 😊 O plano anual sai por R$ 348 (equivale a R$ 29/mês) e inclui todos os recursos. Te enviei o link com a tabela completa por DM — qualquer dúvida, estou por aqui!",
  positivo: "Que alegria ler isso! 💛 Muito obrigado pelo carinho — é isso que faz tudo valer a pena. Se quiser, marca a gente quando chegar: adoramos repostar vocês!",
};

/* ---------- helpers ---------- */

export const cx = (...parts: Array<string | false | null | undefined>) =>
  parts.filter(Boolean).join(" ");

export function fmtCompact(n: number): string {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(".", ",") + " mi";
  if (n >= 1_000) return (n / 1_000).toFixed(1).replace(".", ",") + " mil";
  return String(n);
}

export function fmtInt(n: number): string {
  return n.toLocaleString("pt-BR");
}

/** deterministic pseudo-random series for charts */
export function genSeries(n: number, base: number, amp: number, seed: number): number[] {
  const out: number[] = [];
  let s = seed;
  for (let i = 0; i < n; i++) {
    s = (s * 9301 + 49297) % 233280;
    const rnd = s / 233280;
    const wave = Math.sin(i / 3.2) * amp * 0.6 + Math.sin(i / 1.7) * amp * 0.25;
    out.push(Math.max(4, Math.round(base + wave + rnd * amp)));
  }
  return out;
}

export function ago(ts: number): string {
  const s = Math.max(0, Math.floor((Date.now() - ts) / 1000));
  if (s < 45) return "agora";
  const m = Math.floor(s / 60);
  if (m < 60) return `há ${m} min`;
  return `há ${Math.floor(m / 60)} h`;
}

export function timeToMinutes(t: string): number {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
}

export function minutesLabel(m: number): string {
  const h = Math.floor(m / 60);
  const mm = m % 60;
  return `${String(h).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
}
