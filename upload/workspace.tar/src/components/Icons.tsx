import type { PlatformId } from "../lib/data";

interface IconProps {
  size?: number;
  className?: string;
}

const S = ({ size = 16, className, children, viewBox = "0 0 24 24" }: IconProps & { children: React.ReactNode; viewBox?: string }) => (
  <svg
    width={size}
    height={size}
    viewBox={viewBox}
    fill="none"
    stroke="currentColor"
    strokeWidth={1.8}
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    {children}
  </svg>
);

export function InstagramIcon(p: IconProps) {
  return (
    <S {...p}>
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4.2" />
      <circle cx="17.2" cy="6.8" r="1.1" fill="currentColor" stroke="none" />
    </S>
  );
}

export function XIcon(p: IconProps) {
  return (
    <svg width={p.size ?? 16} height={p.size ?? 16} viewBox="0 0 24 24" fill="currentColor" className={p.className} aria-hidden="true">
      <path d="M17.9 3H21l-6.8 7.8L22.2 21h-6.3l-4.9-6.4L5.4 21H2.2l7.3-8.3L2 3h6.4l4.4 5.9L17.9 3Zm-1.1 16.1h1.7L7.6 4.7H5.8l11 14.4Z" />
    </svg>
  );
}

export function TikTokIcon(p: IconProps) {
  return (
    <S {...p}>
      <path d="M14.5 4v9.7a3.6 3.6 0 1 1-3.1-3.56" />
      <path d="M14.5 4c.5 2.6 2.4 4.6 5 5.1" />
    </S>
  );
}

export function LinkedInIcon(p: IconProps) {
  return (
    <S {...p}>
      <rect x="3" y="3" width="18" height="18" rx="3.5" />
      <circle cx="7.6" cy="8" r="1.15" fill="currentColor" stroke="none" />
      <path d="M7.6 11v6M11.4 17v-3.4a2.3 2.3 0 0 1 4.6 0V17M11.4 11v1.4" />
    </S>
  );
}

export function FacebookIcon(p: IconProps) {
  return (
    <S {...p}>
      <circle cx="12" cy="12" r="9" />
      <path d="M13.4 20.5v-6h2.3l.5-2.8h-2.8V9.9c0-.9.3-1.5 1.5-1.5h1.4V5.9c-.3 0-1.1-.1-2-.1a3.4 3.4 0 0 0-3.6 3.7v2.2H8.5v2.8h2.2v6" />
    </S>
  );
}

export function YouTubeIcon(p: IconProps) {
  return (
    <S {...p}>
      <rect x="2.5" y="5.5" width="19" height="13.5" rx="4" />
      <path d="M10.2 9.4v5.4l4.6-2.7-4.6-2.7Z" fill="currentColor" stroke="none" />
    </S>
  );
}

export function PinterestIcon(p: IconProps) {
  return (
    <S {...p}>
      <circle cx="12" cy="12" r="9" />
      <path d="M10.4 17.5 12 11m-1.9-1.6a2.9 2.9 0 1 1 4.6 2.3c-.8.8-2 .8-2.7.1" />
    </S>
  );
}

export function WhatsAppIcon(p: IconProps) {
  return (
    <S {...p}>
      <path d="M12 3.5a8.5 8.5 0 0 0-7.3 12.8L3.5 20.5l4.4-1.2A8.5 8.5 0 1 0 12 3.5Z" />
      <path d="M9 8.8c-.3 1.6.7 3.5 2.2 4.9 1.4 1.3 3.2 2.2 4.6 1.8l.5-1.5-2-1-.9.7c-.8-.4-1.7-1.3-2.1-2.1l.7-.9-1-2L9 8.8Z" fill="currentColor" stroke="none" />
    </S>
  );
}

export function PlatformIcon({ platform, size = 16, className }: IconProps & { platform: PlatformId }) {
  switch (platform) {
    case "instagram": return <InstagramIcon size={size} className={className} />;
    case "x": return <XIcon size={size} className={className} />;
    case "tiktok": return <TikTokIcon size={size} className={className} />;
    case "linkedin": return <LinkedInIcon size={size} className={className} />;
    case "facebook": return <FacebookIcon size={size} className={className} />;
    case "youtube": return <YouTubeIcon size={size} className={className} />;
    case "pinterest": return <PinterestIcon size={size} className={className} />;
    case "whatsapp": return <WhatsAppIcon size={size} className={className} />;
  }
}

/** Marca do produto: linha de pulso dentro de um quadrado */
export function LogoMark({ size = 34 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none" aria-hidden="true">
      <rect x="1.5" y="1.5" width="37" height="37" rx="11" fill="url(#lg1)" stroke="rgba(255,255,255,0.16)" />
      <path
        d="M7 21h6l3-8 5 15 3.5-9.5L26.5 21H33"
        stroke="#fff"
        strokeWidth="2.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <defs>
        <linearGradient id="lg1" x1="0" y1="0" x2="40" y2="40">
          <stop stopColor="#ff6242" />
          <stop offset="1" stopColor="#e8437a" />
        </linearGradient>
      </defs>
    </svg>
  );
}
