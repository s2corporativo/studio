import { useEffect, useRef, useState, type ReactNode } from "react";
import { X } from "lucide-react";
import { cx } from "../lib/data";

/* ---------- animação de contagem ---------- */
export function useCountUp(target: number, duration = 1100): number {
  const [value, setValue] = useState(0);
  const ref = useRef<number>(0);
  useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      setValue(target * eased);
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    ref.current = raf;
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return value;
}

/* ---------- sparkline ---------- */
export function Sparkline({
  data,
  color = "#45e0ce",
  width = 120,
  height = 36,
  fill = true,
  className,
}: {
  data: number[];
  color?: string;
  width?: number;
  height?: number;
  fill?: boolean;
  className?: string;
}) {
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * width;
    const y = height - 4 - ((v - min) / range) * (height - 8);
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });
  const path = `M${pts.join(" L")}`;
  const id = useRef(`sg${Math.random().toString(36).slice(2, 8)}`).current;
  return (
    <svg width={width} height={height} className={className} aria-hidden="true">
      {fill && (
        <>
          <defs>
            <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity="0.28" />
              <stop offset="100%" stopColor={color} stopOpacity="0" />
            </linearGradient>
          </defs>
          <path d={`${path} L${width},${height} L0,${height} Z`} fill={`url(#${id})`} />
        </>
      )}
      <path
        d={path}
        fill="none"
        stroke={color}
        strokeWidth="1.8"
        strokeLinecap="round"
        style={{ strokeDasharray: 600, ["--dash" as string]: 600 }}
        className="animate-draw"
      />
    </svg>
  );
}

/* ---------- toggle ---------- */
export function Toggle({ on, onChange, accent = "#2bc8b6" }: { on: boolean; onChange: () => void; accent?: string }) {
  return (
    <button
      role="switch"
      aria-checked={on}
      onClick={onChange}
      className="relative h-6 w-11 shrink-0 rounded-full transition-colors duration-300 cursor-pointer"
      style={{ background: on ? accent : "rgba(140,160,200,0.22)" }}
    >
      <span
        className="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow-md transition-all duration-300"
        style={{ left: on ? 22 : 2, boxShadow: on ? `0 2px 10px ${accent}66` : undefined }}
      />
    </button>
  );
}

/* ---------- delta badge ---------- */
export function Delta({ value, suffix = "%" }: { value: number; suffix?: string }) {
  const up = value >= 0;
  return (
    <span
      className={cx(
        "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 font-mono text-[11px] font-medium",
        up ? "bg-emerald-400/10 text-emerald-300" : "bg-rose-400/10 text-rose-300"
      )}
    >
      <svg width="9" height="9" viewBox="0 0 10 10" fill="currentColor" aria-hidden="true">
        {up ? <path d="M5 1 9.3 8H.7L5 1Z" /> : <path d="M5 9 .7 2h8.6L5 9Z" />}
      </svg>
      {Math.abs(value).toFixed(1).replace(".", ",")}{suffix}
    </span>
  );
}

/* ---------- modal ---------- */
export function Modal({
  open,
  onClose,
  children,
  width = 560,
  title,
}: {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  width?: number;
  title?: string;
}) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
      <div className="absolute inset-0 bg-ink-950/78 backdrop-blur-[3px] animate-fade-in" onClick={onClose} />
      <div
        className="panel relative max-h-[92vh] w-full overflow-y-auto shadow-2xl shadow-black/50 animate-pop"
        style={{ maxWidth: width, background: "linear-gradient(180deg,#151f33,#0c1322)" }}
      >
        {title && (
          <div className="sticky top-0 z-10 flex items-center justify-between border-b border-white/6 px-5 py-4" style={{ background: "#131c2ecc", backdropFilter: "blur(8px)" }}>
            <h3 className="font-display text-lg font-semibold tracking-tight">{title}</h3>
            <button
              onClick={onClose}
              className="grid h-8 w-8 place-items-center rounded-lg text-fog-400 transition hover:bg-white/6 hover:text-fog-100 cursor-pointer"
              aria-label="Fechar"
            >
              <X size={17} />
            </button>
          </div>
        )}
        {children}
      </div>
    </div>
  );
}

/* ---------- toasts ---------- */
export interface Toast {
  id: number;
  title: string;
  desc?: string;
  tone: "ok" | "info" | "warn";
}

export function ToastStack({ toasts, dismiss }: { toasts: Toast[]; dismiss: (id: number) => void }) {
  const tones = {
    ok: { bar: "#2bc8b6", icon: "✓" },
    info: { bar: "#5aa7f0", icon: "◆" },
    warn: { bar: "#ffc857", icon: "!" },
  } as const;
  return (
    <div className="pointer-events-none fixed bottom-5 right-5 z-[60] flex w-[340px] flex-col gap-2.5">
      {toasts.map((t) => (
        <div
          key={t.id}
          className="pointer-events-auto relative overflow-hidden rounded-xl border border-white/10 bg-ink-800/95 px-4 py-3 shadow-xl shadow-black/40 animate-slide-in backdrop-blur"
        >
          <span className="absolute inset-y-0 left-0 w-[3px]" style={{ background: tones[t.tone].bar }} />
          <div className="flex items-start gap-3">
            <span
              className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full text-[11px] font-bold"
              style={{ background: `${tones[t.tone].bar}22`, color: tones[t.tone].bar }}
            >
              {tones[t.tone].icon}
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold leading-snug text-fog-100">{t.title}</p>
              {t.desc && <p className="mt-0.5 text-xs leading-snug text-fog-400">{t.desc}</p>}
            </div>
            <button onClick={() => dismiss(t.id)} className="text-fog-500 transition hover:text-fog-200 cursor-pointer" aria-label="Fechar aviso">
              <X size={14} />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---------- título de seção ---------- */
export function SectionHead({ kicker, title, right }: { kicker: string; title: string; right?: ReactNode }) {
  return (
    <div className="mb-4 flex items-end justify-between gap-4">
      <div>
        <p className="font-mono text-[10px] font-medium uppercase tracking-[0.18em] text-coral-400">{kicker}</p>
        <h2 className="mt-1 font-display text-xl font-semibold tracking-tight text-fog-100">{title}</h2>
      </div>
      {right}
    </div>
  );
}
