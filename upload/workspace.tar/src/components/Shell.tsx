import { useEffect, useMemo, useRef, useState } from "react";
import {
  LayoutDashboard, CalendarDays, Bot, BarChart3, Inbox, Share2,
  Search, Bell, Plus, CornerDownRight,
} from "lucide-react";
import { LogoMark } from "./Icons";
import { cx, type Automation, type Mention, type ScheduledPost } from "../lib/data";

export type ViewKey = "overview" | "agenda" | "automations" | "analytics" | "inbox" | "accounts";

const NAV: { key: ViewKey; label: string; icon: typeof LayoutDashboard }[] = [
  { key: "overview", label: "Visão geral", icon: LayoutDashboard },
  { key: "agenda", label: "Agenda", icon: CalendarDays },
  { key: "automations", label: "Automações", icon: Bot },
  { key: "analytics", label: "Análises", icon: BarChart3 },
  { key: "inbox", label: "Caixa de entrada", icon: Inbox },
  { key: "accounts", label: "Contas", icon: Share2 },
];

const VIEW_TITLE: Record<ViewKey, { t: string; s: string }> = {
  overview: { t: "Visão geral", s: "O pulso das suas redes em tempo real" },
  agenda: { t: "Agenda de publicações", s: "Semana de 9 a 15 — arraste o plano, publique no melhor horário" },
  automations: { t: "Motor de automações", s: "Regras que respondem, publicam e organizam por você" },
  analytics: { t: "Análises", s: "Desempenho consolidado de todas as contas" },
  inbox: { t: "Caixa de entrada", s: "Menções, comentários e DMs unificados" },
  accounts: { t: "Contas conectadas", s: "Saúde e sincronização de cada rede" },
};

function LiveClock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  const hh = String(now.getHours()).padStart(2, "0");
  const mm = String(now.getMinutes()).padStart(2, "0");
  const ss = String(now.getSeconds()).padStart(2, "0");
  return (
    <div className="hidden items-center gap-2.5 rounded-xl border border-white/8 bg-ink-900/60 px-3.5 py-2 md:flex">
      <span className="h-2 w-2 rounded-full bg-aqua-400 animate-pulse-dot" />
      <span className="font-mono text-[10px] font-semibold uppercase tracking-[0.16em] text-aqua-300">ao vivo</span>
      <span className="font-mono text-sm tabular-nums text-fog-200">
        {hh}:{mm}<span className="text-fog-500">:{ss}</span>
      </span>
    </div>
  );
}

function GlobalSearch({
  posts, mentions, autos, onGo,
}: {
  posts: ScheduledPost[]; mentions: Mention[]; autos: Automation[]; onGo: (v: ViewKey) => void;
}) {
  const [q, setQ] = useState("");
  const [focus, setFocus] = useState(false);
  const boxRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setFocus(false);
    };
    const k = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        inputRef.current?.focus();
      }
    };
    window.addEventListener("mousedown", h);
    window.addEventListener("keydown", k);
    return () => {
      window.removeEventListener("mousedown", h);
      window.removeEventListener("keydown", k);
    };
  }, []);

  const results = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (term.length < 2) return [];
    const out: { label: string; hint: string; view: ViewKey }[] = [];
    posts.forEach((p) => p.text.toLowerCase().includes(term) && out.push({ label: p.text, hint: "Agenda", view: "agenda" }));
    mentions.forEach((m) => (m.text + m.author).toLowerCase().includes(term) && out.push({ label: `${m.author}: ${m.text}`, hint: "Caixa de entrada", view: "inbox" }));
    autos.forEach((a) => a.name.toLowerCase().includes(term) && out.push({ label: a.name, hint: "Automações", view: "automations" }));
    return out.slice(0, 6);
  }, [q, posts, mentions, autos]);

  return (
    <div ref={boxRef} className="relative hidden w-full max-w-md lg:block">
      <Search size={15} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-fog-500" />
      <input
        ref={inputRef}
        value={q}
        onChange={(e) => setQ(e.target.value)}
        onFocus={() => setFocus(true)}
        placeholder="Buscar posts, menções, automações…"
        className="field w-full py-2.5 pl-10 pr-16 text-sm text-fog-100 placeholder:text-fog-500"
      />
      <kbd className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 rounded-md border border-white/10 bg-ink-700/70 px-1.5 py-0.5 font-mono text-[10px] text-fog-400">
        ⌘K
      </kbd>
      {focus && q.trim().length >= 2 && (
        <div className="absolute left-0 right-0 top-[calc(100%+8px)] z-40 overflow-hidden rounded-xl border border-white/10 bg-ink-800 shadow-2xl shadow-black/50 animate-pop">
          {results.length === 0 ? (
            <p className="px-4 py-5 text-center text-sm text-fog-500">Nada encontrado para “{q}”.</p>
          ) : (
            results.map((r, i) => (
              <button
                key={i}
                onClick={() => { onGo(r.view); setQ(""); setFocus(false); }}
                className="flex w-full items-center gap-3 px-4 py-3 text-left transition hover:bg-white/5 cursor-pointer"
              >
                <CornerDownRight size={13} className="shrink-0 text-coral-400" />
                <span className="min-w-0 flex-1 truncate text-sm text-fog-200">{r.label}</span>
                <span className="shrink-0 rounded-md bg-ink-700 px-2 py-0.5 font-mono text-[10px] uppercase tracking-wide text-fog-400">{r.hint}</span>
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}

function Notifications() {
  const [open, setOpen] = useState(false);
  const items = [
    { t: "Automação “Dúvidas de preço” respondeu 12 comentários", time: "há 38 min", dot: "#2bc8b6" },
    { t: "Facebook: token de acesso expira em 3 dias", time: "há 1 h", dot: "#ffc857" },
    { t: "Post das 09h30 ultrapassou o alcance médio em 2×", time: "há 2 h", dot: "#ff7a5c" },
    { t: "Relatório semanal pronto para revisão", time: "seg, 08:00", dot: "#5aa7f0" },
  ];
  return (
    <div className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        className="relative grid h-10 w-10 place-items-center rounded-xl border border-white/8 bg-ink-900/60 text-fog-300 transition hover:border-white/16 hover:text-fog-100 cursor-pointer"
        aria-label="Notificações"
      >
        <Bell size={17} />
        <span className="absolute right-2.5 top-2.5 h-1.5 w-1.5 rounded-full bg-coral-500" />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-[calc(100%+10px)] z-40 w-[340px] overflow-hidden rounded-xl border border-white/10 bg-ink-800 shadow-2xl shadow-black/50 animate-pop">
            <div className="flex items-center justify-between border-b border-white/6 px-4 py-3">
              <p className="font-display text-sm font-semibold">Notificações</p>
              <span className="rounded-md bg-coral-500/15 px-2 py-0.5 font-mono text-[10px] font-semibold text-coral-300">4 novas</span>
            </div>
            {items.map((n, i) => (
              <div key={i} className="flex items-start gap-3 border-b border-white/4 px-4 py-3 transition last:border-0 hover:bg-white/4">
                <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full" style={{ background: n.dot }} />
                <div className="min-w-0">
                  <p className="text-[13px] leading-snug text-fog-200">{n.t}</p>
                  <p className="mt-0.5 font-mono text-[10px] text-fog-500">{n.time}</p>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default function Shell({
  view, setView, onNewPost, pendingMentions, posts, mentions, autos, children,
}: {
  view: ViewKey;
  setView: (v: ViewKey) => void;
  onNewPost: () => void;
  pendingMentions: number;
  posts: ScheduledPost[];
  mentions: Mention[];
  autos: Automation[];
  children: React.ReactNode;
}) {
  const title = VIEW_TITLE[view];
  const activeAutos = autos.filter((a) => a.active).length;

  return (
    <div className="relative z-10 flex h-full">
      {/* ---------- Sidebar ---------- */}
      <aside className="flex w-[76px] shrink-0 flex-col border-r border-white/6 bg-ink-900/70 backdrop-blur-sm xl:w-[232px]">
        <div className="flex items-center gap-3 px-4 py-5 xl:px-5">
          <LogoMark size={36} />
          <div className="hidden xl:block">
            <p className="font-display text-lg font-bold leading-none tracking-tight">Pulso</p>
            <p className="mt-1 font-mono text-[9px] uppercase tracking-[0.22em] text-fog-500">social ops</p>
          </div>
        </div>

        <nav className="mt-2 flex flex-1 flex-col gap-1 px-3">
          {NAV.map((item) => {
            const active = view === item.key;
            const Icon = item.icon;
            return (
              <button
                key={item.key}
                onClick={() => setView(item.key)}
                className={cx(
                  "group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all duration-200 cursor-pointer",
                  active ? "bg-coral-500/12 text-coral-300" : "text-fog-400 hover:bg-white/5 hover:text-fog-100"
                )}
              >
                {active && <span className="absolute left-0 top-1/2 h-5 w-[3px] -translate-y-1/2 rounded-r bg-coral-500" />}
                <Icon size={17} className="shrink-0" />
                <span className="hidden flex-1 text-left xl:block">{item.label}</span>
                {item.key === "inbox" && pendingMentions > 0 && (
                  <span className="hidden rounded-md bg-coral-500/18 px-1.5 py-0.5 font-mono text-[10px] font-semibold text-coral-300 xl:block">
                    {pendingMentions}
                  </span>
                )}
                {item.key === "inbox" && pendingMentions > 0 && (
                  <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-coral-400 xl:hidden" />
                )}
              </button>
            );
          })}
        </nav>

        <div className="space-y-3 px-3 pb-4">
          <div className="hidden rounded-xl border border-aqua-500/18 bg-aqua-500/6 px-3.5 py-3 xl:block">
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-aqua-400 animate-pulse-dot" />
              <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.14em] text-aqua-300">Motor ativo</p>
            </div>
            <p className="mt-1.5 text-xs leading-snug text-fog-400">
              <span className="font-semibold text-fog-200">{activeAutos} automações</span> monitorando suas contas agora.
            </p>
          </div>
          <div className="flex items-center gap-3 rounded-xl border border-white/6 bg-ink-800/60 px-3 py-2.5">
            <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gradient-to-br from-coral-500 to-[#e8437a] font-display text-sm font-bold text-white">
              MB
            </div>
            <div className="hidden min-w-0 xl:block">
              <p className="truncate text-[13px] font-semibold text-fog-100">Marina Braga</p>
              <p className="truncate font-mono text-[10px] text-fog-500">plano estúdio</p>
            </div>
          </div>
        </div>
      </aside>

      {/* ---------- Main ---------- */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex items-center gap-4 border-b border-white/6 bg-ink-950/80 px-5 py-3.5 backdrop-blur-md lg:px-7">
          <div className="min-w-0 flex-1">
            <h1 className="truncate font-display text-lg font-bold tracking-tight text-fog-100">{title.t}</h1>
            <p className="hidden truncate text-xs text-fog-500 sm:block">{title.s}</p>
          </div>
          <GlobalSearch posts={posts} mentions={mentions} autos={autos} onGo={setView} />
          <LiveClock />
          <Notifications />
          <button
            onClick={onNewPost}
            className="group flex items-center gap-2 rounded-xl bg-coral-500 px-4 py-2.5 text-sm font-semibold text-white shadow-lg shadow-coral-600/25 transition-all hover:bg-coral-400 hover:shadow-coral-500/30 active:scale-[0.97] cursor-pointer"
          >
            <Plus size={16} strokeWidth={2.4} className="transition-transform group-hover:rotate-90" />
            <span className="hidden sm:inline">Nova publicação</span>
          </button>
        </header>

        <main className="min-h-0 flex-1 overflow-y-auto px-5 py-6 lg:px-7">{children}</main>
      </div>
    </div>
  );
}
