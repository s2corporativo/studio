import { useMemo, useState } from "react";
import { CalendarClock, Image as ImageIcon, Link2, Loader2, Send, Sparkles, Video, Layers, Ban } from "lucide-react";
import { PlatformIcon } from "../components/Icons";
import { Modal } from "./ui";
import { AI_CAPTIONS, PLATFORMS, WEEK, cx, type PlatformId, type ScheduledPost } from "../lib/data";

const LIMITS: Record<PlatformId, number> = {
  x: 280, instagram: 2200, tiktok: 2200, linkedin: 3000, facebook: 5000, youtube: 5000, pinterest: 500, whatsapp: 1000,
};

const MEDIA_OPTS: { key: ScheduledPost["media"]; label: string; Icon: typeof ImageIcon }[] = [
  { key: null, label: "Sem mídia", Icon: Ban },
  { key: "imagem", label: "Imagem", Icon: ImageIcon },
  { key: "vídeo", label: "Vídeo", Icon: Video },
  { key: "carrossel", label: "Carrossel", Icon: Layers },
  { key: "link", label: "Link", Icon: Link2 },
];

export default function Composer({
  open, day, time, onClose, onSubmit,
}: {
  open: boolean;
  day: number;
  time: string;
  onClose: () => void;
  onSubmit: (post: ScheduledPost, mode: "agendar" | "rascunho" | "agora") => void;
}) {
  const [platforms, setPlatforms] = useState<PlatformId[]>(["instagram"]);
  const [text, setText] = useState("");
  const [d, setD] = useState(day);
  const [t, setT] = useState(time);
  const [media, setMedia] = useState<ScheduledPost["media"]>(null);
  const [generating, setGenerating] = useState(false);
  const [captionIdx, setCaptionIdx] = useState(0);

  // sincroniza valores iniciais quando o modal abre com novo horário
  const [lastKey, setLastKey] = useState("");
  const key = `${open}-${day}-${time}`;
  if (open && key !== lastKey) {
    setLastKey(key);
    setD(day);
    setT(time);
  }

  const limit = useMemo(
    () => Math.min(...platforms.map((p) => LIMITS[p])),
    [platforms]
  );
  const remaining = limit - text.length;
  const overPct = text.length / limit;

  const togglePlatform = (p: PlatformId) =>
    setPlatforms((prev) => (prev.includes(p) ? prev.filter((x) => x !== p) : [...prev, p]));

  const generate = () => {
    if (generating) return;
    setGenerating(true);
    setTimeout(() => {
      setText(AI_CAPTIONS[captionIdx % AI_CAPTIONS.length]);
      setCaptionIdx((i) => i + 1);
      setGenerating(false);
    }, 1000);
  };

  const valid = platforms.length > 0 && text.trim().length > 0 && remaining >= 0;

  const build = (status: ScheduledPost["status"]): ScheduledPost => ({
    id: `p${Date.now()}`,
    day: d,
    time: t,
    platforms,
    text: text.trim(),
    media,
    status,
  });

  const reset = () => {
    setText("");
    setMedia(null);
    setPlatforms(["instagram"]);
  };

  return (
    <Modal open={open} onClose={() => { onClose(); reset(); }} title="Nova publicação" width={620}>
      <div className="space-y-5 p-5">
        {/* plataformas */}
        <div>
          <p className="mb-2 font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-fog-500">Publicar em</p>
          <div className="flex flex-wrap gap-2">
            {(Object.keys(LIMITS) as PlatformId[]).slice(0, 6).map((p) => {
              const on = platforms.includes(p);
              return (
                <button
                  key={p}
                  onClick={() => togglePlatform(p)}
                  className={cx(
                    "flex items-center gap-2 rounded-xl border px-3 py-2 text-[13px] font-semibold transition-all cursor-pointer",
                    on ? "border-transparent shadow-md" : "border-white/10 text-fog-500 hover:text-fog-200"
                  )}
                  style={on ? { background: PLATFORMS[p].tint, color: PLATFORMS[p].color, boxShadow: `0 4px 18px -8px ${PLATFORMS[p].color}66` } : undefined}
                >
                  <PlatformIcon platform={p} size={15} /> {PLATFORMS[p].name}
                </button>
              );
            })}
          </div>
        </div>

        {/* texto */}
        <div>
          <div className="mb-2 flex items-center justify-between">
            <p className="font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-fog-500">Legenda</p>
            <button
              onClick={generate}
              disabled={generating}
              className="flex items-center gap-1.5 rounded-lg border border-coral-500/35 bg-coral-500/10 px-2.5 py-1 text-[11px] font-semibold text-coral-300 transition hover:bg-coral-500/18 disabled:opacity-60 cursor-pointer"
            >
              {generating ? (<><Loader2 size={12} className="animate-spin" /> Gerando…</>) : (<><Sparkles size={12} /> Gerar legenda com IA</>)}
            </button>
          </div>
          <div className="relative">
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={4}
              placeholder="O que você quer dizer para a sua audiência hoje?"
              className="field w-full resize-none px-4 py-3 text-sm leading-relaxed text-fog-100 placeholder:text-fog-600"
            />
            {generating && <span className="absolute bottom-3 right-3 h-4 w-0.5 bg-coral-400 animate-blink" />}
          </div>
          <div className="mt-2 flex items-center gap-3">
            <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-ink-700/70">
              <div
                className="h-full rounded-full transition-all duration-300"
                style={{
                  width: `${Math.min(100, overPct * 100)}%`,
                  background: remaining < 0 ? "#ff6b5e" : overPct > 0.8 ? "#ffc857" : "#45e0ce",
                }}
              />
            </div>
            <span className={cx("font-mono text-[11px] tabular-nums", remaining < 0 ? "text-rose-400 font-semibold" : "text-fog-500")}>
              {text.length}/{limit}
            </span>
          </div>
        </div>

        {/* mídia */}
        <div>
          <p className="mb-2 font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-fog-500">Mídia</p>
          <div className="flex flex-wrap gap-1.5">
            {MEDIA_OPTS.map((m) => (
              <button
                key={m.label}
                onClick={() => setMedia(m.key)}
                className={cx(
                  "flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-[11px] font-semibold transition cursor-pointer",
                  media === m.key ? "border-aqua-500/45 bg-aqua-500/10 text-aqua-300" : "border-white/10 text-fog-500 hover:text-fog-200"
                )}
              >
                <m.Icon size={12} /> {m.label}
              </button>
            ))}
          </div>
        </div>

        {/* agendamento */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <p className="mb-1.5 font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-fog-500">Dia</p>
            <select value={d} onChange={(e) => setD(Number(e.target.value))} className="field w-full px-3 py-2.5 text-sm text-fog-100 cursor-pointer">
              {WEEK.map((w, i) => (
                <option key={w.d} value={i} className="bg-ink-800">{w.d} · {w.n}{i === 3 ? " (hoje)" : ""}</option>
              ))}
            </select>
          </div>
          <div>
            <p className="mb-1.5 font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-fog-500">Horário</p>
            <div className="flex gap-2">
              <input type="time" value={t} onChange={(e) => setT(e.target.value)} className="field w-full px-3 py-2 font-mono text-sm text-fog-100 [color-scheme:dark]" />
            </div>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="font-mono text-[10px] uppercase tracking-wide text-fog-600">Picos sugeridos:</span>
          {["12:00", "19:00"].map((ht) => (
            <button
              key={ht}
              onClick={() => setT(ht)}
              className={cx(
                "rounded-md px-2 py-1 font-mono text-[11px] font-semibold transition cursor-pointer",
                t === ht ? "bg-aqua-500/16 text-aqua-300" : "border border-white/10 text-fog-500 hover:text-fog-200"
              )}
            >
              {ht}
            </button>
          ))}
        </div>

        {/* ações */}
        <div className="flex flex-wrap items-center gap-2.5 border-t border-white/6 pt-4">
          <button
            onClick={() => { onSubmit(build("rascunho"), "rascunho"); reset(); onClose(); }}
            disabled={!text.trim()}
            className="rounded-xl border border-white/12 px-4 py-2.5 text-[13px] font-semibold text-fog-300 transition hover:bg-white/5 disabled:cursor-not-allowed disabled:opacity-35 cursor-pointer"
          >
            Salvar rascunho
          </button>
          <button
            onClick={() => { onSubmit(build("agendada"), "agendar"); reset(); onClose(); }}
            disabled={!valid}
            className="flex items-center gap-2 rounded-xl bg-coral-500 px-4 py-2.5 text-[13px] font-bold text-white shadow-lg shadow-coral-600/25 transition hover:bg-coral-400 active:scale-[0.97] disabled:cursor-not-allowed disabled:opacity-35 cursor-pointer"
          >
            <CalendarClock size={15} /> Agendar para {WEEK[d].d} {t}
          </button>
          <button
            onClick={() => { onSubmit(build("publicada"), "agora"); reset(); onClose(); }}
            disabled={!valid}
            className="ml-auto flex items-center gap-2 rounded-xl border border-aqua-500/40 bg-aqua-500/10 px-4 py-2.5 text-[13px] font-bold text-aqua-300 transition hover:bg-aqua-500/18 active:scale-[0.97] disabled:cursor-not-allowed disabled:opacity-35 cursor-pointer"
          >
            <Send size={14} /> Publicar agora
          </button>
        </div>
      </div>
    </Modal>
  );
}
