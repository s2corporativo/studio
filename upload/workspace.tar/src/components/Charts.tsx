import { useId, useRef, useState } from "react";
import { fmtCompact } from "../lib/data";

export interface Series {
  name: string;
  color: string;
  data: number[];
}

export function AreaChart({
  series,
  height = 230,
  labelFor,
  valueFmt = fmtCompact,
}: {
  series: Series[];
  height?: number;
  labelFor?: (i: number) => string;
  valueFmt?: (n: number) => string;
}) {
  const uid = useId().replace(/[:]/g, "");
  const W = 600;
  const H = height;
  const padL = 6, padR = 6, padT = 16, padB = 8;
  const n = series[0].data.length;
  const max = Math.max(...series.flatMap((s) => s.data)) * 1.12;
  const svgRef = useRef<SVGSVGElement>(null);
  const [hover, setHover] = useState<number | null>(null);

  const x = (i: number) => padL + (i / (n - 1)) * (W - padL - padR);
  const y = (v: number) => padT + (1 - v / max) * (H - padT - padB);
  const path = (data: number[]) => `M${data.map((v, i) => `${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" L")}`;

  const onMove = (e: React.MouseEvent) => {
    const rect = svgRef.current?.getBoundingClientRect();
    if (!rect) return;
    const px = ((e.clientX - rect.left) / rect.width) * W;
    const idx = Math.round(((px - padL) / (W - padL - padR)) * (n - 1));
    setHover(Math.max(0, Math.min(n - 1, idx)));
  };

  return (
    <div className="relative">
      <svg
        ref={svgRef}
        viewBox={`0 0 ${W} ${H}`}
        className="w-full"
        style={{ height }}
        onMouseMove={onMove}
        onMouseLeave={() => setHover(null)}
      >
        <defs>
          {series.map((s, si) => (
            <linearGradient key={si} id={`${uid}-g${si}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={s.color} stopOpacity="0.26" />
              <stop offset="100%" stopColor={s.color} stopOpacity="0" />
            </linearGradient>
          ))}
        </defs>
        {[0.25, 0.5, 0.75].map((f) => (
          <line
            key={f}
            x1={padL}
            x2={W - padR}
            y1={padT + f * (H - padT - padB)}
            y2={padT + f * (H - padT - padB)}
            stroke="rgba(140,160,200,0.1)"
            strokeDasharray="3 5"
          />
        ))}
        {series.map((s, si) => (
          <g key={si}>
            <path
              d={`${path(s.data)} L${x(n - 1)},${H - padB} L${x(0)},${H - padB} Z`}
              fill={`url(#${uid}-g${si})`}
            />
            <path
              d={path(s.data)}
              fill="none"
              stroke={s.color}
              strokeWidth="2.2"
              strokeLinecap="round"
              style={{ strokeDasharray: 1400, ["--dash" as string]: 1400 }}
              className="animate-draw"
            />
          </g>
        ))}
        {hover !== null && (
          <g>
            <line x1={x(hover)} x2={x(hover)} y1={padT - 6} y2={H - padB} stroke="rgba(237,242,251,0.25)" strokeDasharray="3 4" />
            {series.map((s, si) => (
              <circle key={si} cx={x(hover)} cy={y(s.data[hover])} r="4.5" fill={s.color} stroke="#0a0f1a" strokeWidth="2" />
            ))}
          </g>
        )}
      </svg>

      {hover !== null && (
        <div
          className="pointer-events-none absolute z-10 -translate-x-1/2 rounded-lg border border-white/10 bg-ink-900/95 px-3 py-2 shadow-xl shadow-black/40"
          style={{ left: `${(hover / (n - 1)) * 100}%`, top: -8 }}
        >
          {labelFor && <p className="mb-1 font-mono text-[10px] uppercase tracking-wide text-fog-500">{labelFor(hover)}</p>}
          {series.map((s, si) => (
            <p key={si} className="flex items-center gap-2 text-xs font-semibold text-fog-100">
              <span className="h-2 w-2 rounded-full" style={{ background: s.color }} />
              {s.name}: <span className="font-mono">{valueFmt(s.data[hover])}</span>
            </p>
          ))}
        </div>
      )}
    </div>
  );
}
