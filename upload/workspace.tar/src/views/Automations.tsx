import { useState } from "react";
import { AlertTriangle, ArrowRight, Bot, CheckCircle2, History, Loader2, Play, Plus, Sparkles, Timer } from "lucide-react";
import { PlatformIcon } from "../components/Icons";
import { SectionHead, Toggle, useCountUp } from "../components/ui";
import { PLATFORMS, cx, fmtInt, type Automation, type PlatformId, type RunLog } from "../lib/data";

export const TRIGGERS = [
  "Novo seguidor no Instagram",
  "Comentário contém palavra-chave",
  "Menção à marca em qualquer rede",
  "Queda de engajamento por 24 h",
  "Horário de pico detectado",
  "Toda segunda-feira às 08:00",
  "Novo comentário em vídeo",
];

export const ACTIONS = [
  "Enviar DM de boas-vindas com cupom",
  "Responder com template aprovado",
  "Adicionar à fila de republicação",
  "Notificar a equipe no Slack",
  "Agendar repost no melhor horário",
  "Enviar relatório por e-mail",
  "Etiquetar e mover para a caixa de entrada",
];

const NEW_PLATFORMS: PlatformId[] = ["instagram", "x", "tiktok", "linkedin"];

export default function Automations({
  autos, log, onToggle, onRun, onAdd,
}: {
  autos: Automation[];
  log: RunLog[];
  onToggle: (id: string) => void;
  onRun: (id: string) => void;
  onAdd: (a: Automation) => void;
}) {
  const [runningId, setRunningId] = useState<string | null>(null);
  const [trigger, setTrigger] = useState(TRIGGERS[1]);
  const [action, setAction] = useState(ACTIONS[1]);
  const [platforms, setPlatforms] = useState<PlatformId[]>(["instagram"]);
  const actions = useCountUp(2396, 1300);

  const run = (id: string) => {
    if (runningId) return;
    setRunningId(id);
    setTimeout(() => {
      onRun(id);
      setRunningId(null);
    }, 1400);
  };

  const submit = () => {
    if (platforms.length === 0) return;
    onAdd({
      id: `r${Date.now()}`,
      name: action.split(" ").slice(0, 4).join(" ") + "…",
      trigger,
      action,
      platforms,
      active: true,
      runs: 0,
      lastRun: "nunca executada",
    });
  };

  const stats = [
    { label: "Ações neste mês", value: fmtInt(Math.round(actions)), icon: Sparkles, color: "#45e0ce" },
    { label: "Tempo economizado", value: "46 h", icon: Timer, color: "#ff7a5c" },
    { label: "Taxa de sucesso", value: "99,2%", icon: CheckCircle2, color: "#ffc857" },
    { label: "Regras ativas", value: `${autos.filter((a) => a.active).length}/${autos.length}`, icon: Bot, color: "#b692f6" },
  ];

  return (
    <div className="mx-auto max-w-[1240px] space-y-5">
      <div className="stagger grid grid-cols-2 gap-3.5 xl:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="panel panel-hover flex items-center gap-3.5 p-4">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl" style={{ background: `${s.color}16`, color: s.color }}>
              <s.icon size={18} />
            </span>
            <div>
              <p className="font-display text-xl font-bold leading-none tracking-tight">{s.value}</p>
              <p className="mt-1 text-[11px] text-fog-500">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-12 gap-5">
        <div className="col-span-12 space-y-3.5 xl:col-span-7">
          <SectionHead kicker="Regras ativas" title="O que roda no piloto automático" />
          {autos.map((a, idx) => (
            <div
              key={a.id}
              className={cx(
                "panel panel-hover p-4 animate-fade-up",
                !a.active && "opacity-65"
              )}
              style={{ animationDelay: `${0.05 * idx}s` }}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <span className={cx("mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-xl", a.active ? "bg-aqua-500/12 text-aqua-300" : "bg-ink-700/70 text-fog-500")}>
                    <Bot size={17} />
                  </span>
                  <div>
                    <h4 className="font-display text-[15px] font-semibold tracking-tight">{a.name}</h4>
                    <p className="mt-1.5 flex flex-wrap items-center gap-1.5 text-xs text-fog-400">
                      <span className="rounded-md bg-ink-700/70 px-2 py-0.5 text-fog-300">Quando: {a.trigger}</span>
                      <ArrowRight size={12} className="text-coral-400" />
                      <span className="rounded-md bg-coral-500/12 px-2 py-0.5 text-coral-300">Então: {a.action}</span>
                    </p>
                    <div className="mt-2 flex flex-wrap items-center gap-2">
                      <span className="flex -space-x-1">
                        {a.platforms.map((pl) => (
                          <span key={pl} className="grid h-6 w-6 place-items-center rounded-full border border-ink-700" style={{ background: PLATFORMS[pl].tint, color: PLATFORMS[pl].color }}>
                            <PlatformIcon platform={pl} size={11} />
                          </span>
                        ))}
                      </span>
                      <span className="font-mono text-[10px] text-fog-500">{fmtInt(a.runs)} execuções · última {a.lastRun}</span>
                    </div>
                  </div>
                </div>
                <Toggle on={a.active} onChange={() => onToggle(a.id)} />
              </div>
              <div className="mt-3 flex items-center justify-end border-t border-white/5 pt-3">
                <button
                  onClick={() => run(a.id)}
                  disabled={runningId !== null}
                  className={cx(
                    "flex items-center gap-2 rounded-lg border px-3 py-1.5 text-xs font-semibold transition cursor-pointer",
                    runningId === a.id
                      ? "border-aqua-500/40 bg-aqua-500/10 text-aqua-300"
                      : "border-white/10 text-fog-300 hover:border-aqua-500/40 hover:text-aqua-300",
                    runningId !== null && runningId !== a.id && "opacity-40"
                  )}
                >
                  {runningId === a.id ? (<><Loader2 size={13} className="animate-spin" /> Executando…</>) : (<><Play size={12} /> Executar agora</>)}
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="col-span-12 space-y-5 xl:col-span-5">
          <section className="panel p-5 animate-fade-up" style={{ animationDelay: "0.1s" }}>
            <SectionHead kicker="Nova regra" title="Criar automação" />
            <label className="mb-1.5 block font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-fog-500">Quando (gatilho)</label>
            <select value={trigger} onChange={(e) => setTrigger(e.target.value)} className="field w-full px-3 py-2.5 text-sm text-fog-100 cursor-pointer">
              {TRIGGERS.map((t) => <option key={t} value={t} className="bg-ink-800">{t}</option>)}
            </select>
            <label className="mb-1.5 mt-4 block font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-fog-500">Então (ação)</label>
            <select value={action} onChange={(e) => setAction(e.target.value)} className="field w-full px-3 py-2.5 text-sm text-fog-100 cursor-pointer">
              {ACTIONS.map((t) => <option key={t} value={t} className="bg-ink-800">{t}</option>)}
            </select>
            <label className="mb-1.5 mt-4 block font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-fog-500">Contas</label>
            <div className="flex flex-wrap gap-1.5">
              {NEW_PLATFORMS.map((pl) => {
                const on = platforms.includes(pl);
                return (
                  <button
                    key={pl}
                    onClick={() => setPlatforms((prev) => on ? prev.filter((p) => p !== pl) : [...prev, pl])}
                    className={cx(
                      "flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs font-semibold transition cursor-pointer",
                      on ? "border-transparent" : "border-white/10 text-fog-500 hover:text-fog-200"
                    )}
                    style={on ? { background: PLATFORMS[pl].tint, color: PLATFORMS[pl].color } : undefined}
                  >
                    <PlatformIcon platform={pl} size={13} /> {PLATFORMS[pl].name}
                  </button>
                );
              })}
            </div>
            <button
              onClick={submit}
              disabled={platforms.length === 0}
              className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-aqua-500 py-2.5 text-sm font-bold text-ink-950 transition hover:bg-aqua-400 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40 cursor-pointer"
            >
              <Plus size={15} strokeWidth={2.5} /> Ativar automação
            </button>
            <p className="mt-2.5 text-center text-[11px] text-fog-500">A regra entra em vigor imediatamente, sem código.</p>
          </section>

          <section className="panel overflow-hidden animate-fade-up" style={{ animationDelay: "0.18s" }}>
            <div className="flex items-center gap-2 border-b border-white/6 px-5 py-3.5">
              <History size={15} className="text-fog-400" />
              <h3 className="font-display text-sm font-semibold">Registro de execuções</h3>
              <span className="ml-auto font-mono text-[10px] text-fog-500">hoje</span>
            </div>
            <div className="max-h-[340px] divide-y divide-white/4 overflow-y-auto">
              {log.map((l) => (
                <div key={l.id} className="flex items-start gap-3 px-5 py-3 animate-fade-in">
                  <span className="mt-0.5 font-mono text-[11px] tabular-nums text-fog-500">{l.time}</span>
                  {l.status === "ok"
                    ? <CheckCircle2 size={14} className="mt-0.5 shrink-0 text-aqua-400" />
                    : <AlertTriangle size={14} className="mt-0.5 shrink-0 text-amberx-400" />}
                  <p className="text-[13px] leading-snug text-fog-300">{l.text}</p>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
