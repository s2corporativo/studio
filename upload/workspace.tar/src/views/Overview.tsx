import { useMemo, useState } from "react";
import { Heart, UserPlus, MessageCircle, Zap, TrendingUp, Repeat2, Sparkles, Check, ArrowRight, CalendarClock } from "lucide-react";
import { AreaChart } from "../components/Charts";
import { Sparkline, useCountUp, Delta } from "../components/ui";
import { PlatformIcon } from "../components/Icons";
import {
  HASHTAGS, PLATFORMS, WEEK, ago, cx, fmtCompact, genSeries, timeToMinutes,
  type FeedEvent, type ScheduledPost,
} from "../lib/data";
import type { ViewKey } from "../components/Shell";

const EVENT_META: Record<FeedEvent["icon"], { Icon: typeof Heart; color: string }> = {
  heart: { Icon: Heart, color: "#ff5c8a" },
  user: { Icon: UserPlus, color: "#45e0ce" },
  comment: { Icon: MessageCircle, color: "#5aa7f0" },
  zap: { Icon: Zap, color: "#ffc857" },
  trend: { Icon: TrendingUp, color: "#ff7a5c" },
  share: { Icon: Repeat2, color: "#b692f6" },
};

function KpiCard({ label, value, delta, color, data, note, suffix = "" }: {
  label: string; value: number; delta?: number; color: string; data: number[]; note?: string; suffix?: string;
}) {
  const v = useCountUp(value);
  return (
    <div className="panel panel-hover relative overflow-hidden p-4">
      <span className="absolute inset-x-0 top-0 h-[2px]" style={{ background: `linear-gradient(90deg, ${color}, transparent 70%)` }} />
      <div className="flex items-start justify-between gap-2">
        <p className="font-mono text-[10px] font-medium uppercase tracking-[0.16em] text-fog-500">{label}</p>
        {delta !== undefined && <Delta value={delta} />}
      </div>
      <div className="mt-2 flex items-end justify-between gap-3">
        <p className="font-display text-[30px] font-bold leading-none tracking-tight" style={{ color }}>
          {suffix ? `${Math.round(v)}${suffix}` : fmtCompact(Math.round(v))}
        </p>
        <Sparkline data={data} color={color} width={92} height={34} />
      </div>
      {note && <p className="mt-2 text-[11px] text-fog-500">{note}</p>}
    </div>
  );
}

export default function Overview({
  posts, events, onNavigate, onQuickSchedule,
}: {
  posts: ScheduledPost[];
  events: FeedEvent[];
  onNavigate: (v: ViewKey) => void;
  onQuickSchedule: () => void;
}) {
  const [range, setRange] = useState<7 | 14 | 30>(14);
  const [suggested, setSuggested] = useState(false);

  const chartSeries = useMemo(
    () => [
      { name: "Engajamento", color: "#45e0ce", data: genSeries(range, 2400, 900, range * 3 + 1) },
      { name: "Alcance", color: "#ff7a5c", data: genSeries(range, 6800, 2200, range * 7 + 5) },
    ],
    [range]
  );

  const today = 3; // quinta-feira
  const queue = useMemo(
    () =>
      posts
        .filter((p) => p.status === "agendada")
        .sort((a, b) => a.day - b.day || timeToMinutes(a.time) - timeToMinutes(b.time))
        .slice(0, 6),
    [posts]
  );

  const countdown = (day: number) => {
    const diff = (day - today + 7) % 7;
    if (diff === 0) return "hoje";
    if (diff === 1) return "amanhã";
    return `em ${diff} d`;
  };

  return (
    <div className="mx-auto max-w-[1240px] space-y-5">
      {/* ticker de assuntos monitorados */}
      <div className="ticker-mask overflow-hidden border-y border-white/5 py-2.5">
        <div className="flex w-max items-center animate-ticker">
          {[0, 1].map((dup) =>
            HASHTAGS.map((h, i) => (
              <span key={`${dup}-${i}`} className="flex items-center gap-2 whitespace-nowrap pr-8">
                <span className="font-mono text-xs font-semibold text-coral-400">{h.tag}</span>
                <span className="text-[11px] text-fog-500">{h.vol}</span>
                <span className="pl-6 text-ink-600">✦</span>
              </span>
            ))
          )}
        </div>
      </div>

      {/* KPIs */}
      <div className="stagger grid grid-cols-2 gap-3.5 xl:grid-cols-4">
        <KpiCard label="Alcance · 7 dias" value={486300} delta={12.8} color="#ff7a5c" data={genSeries(12, 60, 30, 3)} note="Melhor dia: quinta, 19h" />
        <KpiCard label="Engajamento" value={38900} delta={8.1} color="#45e0ce" data={genSeries(12, 50, 26, 11)} note="Curtidas + respostas + saves" />
        <KpiCard label="Seguidores" value={285100} delta={1.9} color="#ffc857" data={genSeries(12, 70, 18, 5)} note="+5.340 na semana" />
        <KpiCard label="Posts automáticos" value={79} delta={6.2} color="#b692f6" data={genSeries(12, 55, 22, 9)} note="11 de 14 publicações da semana" suffix="%" />
      </div>

      <div className="grid grid-cols-12 gap-5">
        {/* coluna principal */}
        <div className="col-span-12 space-y-5 xl:col-span-8">
          <section className="panel p-5 animate-fade-up" style={{ animationDelay: "0.1s" }}>
            <div className="mb-1 flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="font-display text-base font-semibold tracking-tight">Ritmo das publicações</h3>
                <p className="text-xs text-fog-500">Engajamento × alcance · todas as contas</p>
              </div>
              <div className="flex items-center gap-1 rounded-lg border border-white/8 bg-ink-900/60 p-1">
                {([7, 14, 30] as const).map((r) => (
                  <button
                    key={r}
                    onClick={() => setRange(r)}
                    className={cx(
                      "rounded-md px-2.5 py-1 font-mono text-[11px] font-semibold transition cursor-pointer",
                      range === r ? "bg-coral-500/20 text-coral-300" : "text-fog-500 hover:text-fog-200"
                    )}
                  >
                    {r}d
                  </button>
                ))}
              </div>
            </div>
            <div className="mt-3 flex items-center gap-5">
              {chartSeries.map((s) => (
                <span key={s.name} className="flex items-center gap-1.5 text-[11px] text-fog-400">
                  <span className="h-2 w-2 rounded-full" style={{ background: s.color }} /> {s.name}
                </span>
              ))}
            </div>
            <div className="mt-2">
              <AreaChart series={chartSeries} height={236} labelFor={(i) => `dia ${i + 1} · ${range}d`} />
            </div>
          </section>

          <section className="panel p-5 animate-fade-up" style={{ animationDelay: "0.16s" }}>
            <div className="mb-3 flex items-center justify-between">
              <div>
                <h3 className="font-display text-base font-semibold tracking-tight">Fila de publicações</h3>
                <p className="text-xs text-fog-500">{queue.length} agendadas · próxima sai sozinha, sem esforço</p>
              </div>
              <button
                onClick={() => onNavigate("agenda")}
                className="group flex items-center gap-1.5 text-xs font-semibold text-coral-400 transition hover:text-coral-300 cursor-pointer"
              >
                Abrir agenda <ArrowRight size={13} className="transition-transform group-hover:translate-x-0.5" />
              </button>
            </div>
            <div className="divide-y divide-white/5">
              {queue.map((p) => (
                <button
                  key={p.id}
                  onClick={() => onNavigate("agenda")}
                  className="group flex w-full items-center gap-3.5 py-2.5 text-left transition hover:bg-white/3 cursor-pointer"
                >
                  <span className="grid w-12 shrink-0 place-items-center rounded-lg border border-white/8 bg-ink-900/70 py-1.5">
                    <span className="font-mono text-[10px] font-semibold uppercase text-fog-400">{WEEK[p.day].d}</span>
                    <span className="font-display text-sm font-bold leading-none text-fog-100">{WEEK[p.day].n}</span>
                  </span>
                  <span className="w-12 shrink-0 font-mono text-xs text-aqua-300">{p.time}</span>
                  <span className="flex shrink-0 -space-x-1">
                    {p.platforms.map((pl) => (
                      <span key={pl} className="grid h-6 w-6 place-items-center rounded-full border border-ink-700" style={{ background: PLATFORMS[pl].tint, color: PLATFORMS[pl].color }}>
                        <PlatformIcon platform={pl} size={12} />
                      </span>
                    ))}
                  </span>
                  <span className="min-w-0 flex-1 truncate text-[13px] text-fog-300 group-hover:text-fog-100">{p.text}</span>
                  <span className="shrink-0 rounded-md bg-ink-700/70 px-2 py-1 font-mono text-[10px] font-semibold text-fog-300">
                    {countdown(p.day)}
                  </span>
                </button>
              ))}
            </div>
          </section>
        </div>

        {/* coluna lateral */}
        <div className="col-span-12 space-y-5 xl:col-span-4">
          <section className="panel overflow-hidden animate-fade-up" style={{ animationDelay: "0.12s" }}>
            <div className="flex items-center gap-2.5 border-b border-white/6 px-5 py-4">
              <span className="h-2 w-2 rounded-full bg-aqua-400 animate-pulse-dot" />
              <h3 className="font-display text-base font-semibold tracking-tight">Atividade agora</h3>
              <span className="ml-auto font-mono text-[10px] uppercase tracking-widest text-fog-500">auto</span>
            </div>
            <div className="max-h-[330px] overflow-y-auto px-2.5 py-2">
              {events.map((e, i) => {
                const meta = EVENT_META[e.icon];
                return (
                  <div key={e.id} className={cx("flex items-start gap-3 rounded-xl px-2.5 py-2.5 transition hover:bg-white/4", i === 0 && "animate-slide-in")}>
                    <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg" style={{ background: `${meta.color}1a`, color: meta.color }}>
                      <meta.Icon size={15} />
                    </span>
                    <div className="min-w-0">
                      <p className="text-[13px] leading-snug text-fog-200">{e.text}</p>
                      <p className="mt-0.5 flex items-center gap-1.5 font-mono text-[10px] text-fog-500">
                        {e.platform && <PlatformIcon platform={e.platform} size={10} />}
                        {ago(e.ts)}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          <section
            className="relative overflow-hidden rounded-[14px] border border-coral-500/25 p-5 animate-fade-up"
            style={{ animationDelay: "0.2s", background: "linear-gradient(160deg, rgba(255,98,66,0.13), rgba(13,20,34,0.94) 55%)" }}
          >
            <div className="flex items-center gap-2">
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-coral-500/20 text-coral-300">
                <Sparkles size={16} />
              </span>
              <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.18em] text-coral-300">Sugestão do Pulso</p>
            </div>
            <p className="mt-3 text-sm leading-relaxed text-fog-200">
              Seu público está <span className="font-semibold text-fog-100">2,3× mais ativo hoje às 19h</span>. Publique o reel pendente agora e pegue o pico de engajamento.
            </p>
            <div className="mt-4 flex items-center gap-3">
              <button
                disabled={suggested}
                onClick={() => { onQuickSchedule(); setSuggested(true); }}
                className={cx(
                  "flex items-center gap-2 rounded-lg px-3.5 py-2 text-[13px] font-semibold transition-all cursor-pointer",
                  suggested
                    ? "cursor-default bg-aqua-500/15 text-aqua-300"
                    : "bg-coral-500 text-white shadow-lg shadow-coral-600/25 hover:bg-coral-400 active:scale-[0.97]"
                )}
              >
                {suggested ? (<><Check size={14} /> Agendado para 19h</>) : (<><CalendarClock size={14} /> Agendar para hoje, 19h</>)}
              </button>
              <span className="font-mono text-[10px] text-fog-500">IA · baseado em 30 dias</span>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
