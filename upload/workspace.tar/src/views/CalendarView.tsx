import { useEffect, useMemo, useState, type MouseEvent } from "react";
import { Check, Clock3, X, Zap } from "lucide-react";
import { PlatformIcon } from "../components/Icons";
import {
  PLATFORMS, WEEK, cx, fmtCompact, minutesLabel, timeToMinutes,
  type PlatformId, type ScheduledPost,
} from "../lib/data";

const DAY_START = 8 * 60;
const DAY_END = 22 * 60;
const SPAN = DAY_END - DAY_START;
const COL_H = 560;
const TODAY = 3; // quinta

const FILTERS: PlatformId[] = ["instagram", "x", "tiktok", "linkedin", "facebook", "youtube"];

export default function CalendarView({
  posts, onDelete, onSlotClick, onMove,
}: {
  posts: ScheduledPost[];
  onDelete: (id: string) => void;
  onSlotClick: (day: number, time: string) => void;
  onMove: (id: string, day: number, time: string) => void;
}) {
  const [filter, setFilter] = useState<PlatformId | null>(null);
  const [ghost, setGhost] = useState<{ day: number; time: string; top: number } | null>(null);
  const [dragId, setDragId] = useState<string | null>(null);
  const [dragSlot, setDragSlot] = useState<{ day: number; time: string; top: number } | null>(null);

  /* relógio vivo: linha do "agora" e contagem regressiva */
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 15_000);
    return () => clearInterval(t);
  }, []);
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const nowLabel = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;

  const nextPost = useMemo(() => {
    const cands = posts
      .filter((p) => p.status === "agendada")
      .map((p) => {
        const m = timeToMinutes(p.time);
        let days = (p.day - TODAY + 7) % 7;
        if (p.day === TODAY && m <= nowMin) days = 7;
        return { p, diff: days * 1440 + m - nowMin };
      })
      .filter((c) => c.diff > 0)
      .sort((a, b) => a.diff - b.diff);
    return cands[0] ?? null;
  }, [posts, nowMin]);

  const nextLabel = nextPost
    ? nextPost.diff < 1440 && nextPost.p.day === TODAY
      ? `hoje, ${nextPost.p.time}`
      : nextPost.diff < 1440
      ? `amanhã, ${nextPost.p.time}`
      : `${WEEK[nextPost.p.day].d} ${nextPost.p.day === TODAY ? "" : WEEK[nextPost.p.day].n + " · "}${nextPost.p.time}`
    : null;

  const inLabel = nextPost
    ? nextPost.diff >= 1440
      ? `em ${Math.floor(nextPost.diff / 1440)}d ${Math.floor((nextPost.diff % 1440) / 60)}h`
      : nextPost.diff >= 60
      ? `em ${Math.floor(nextPost.diff / 60)}h ${String(nextPost.diff % 60).padStart(2, "0")}min`
      : `em ${nextPost.diff}min`
    : "";

  const visible = useMemo(
    () => (filter ? posts.filter((p) => p.platforms.includes(filter)) : posts),
    [posts, filter]
  );
  const counts = useMemo(
    () => ({
      ag: posts.filter((p) => p.status === "agendada").length,
      pub: posts.filter((p) => p.status === "publicada").length,
      dr: posts.filter((p) => p.status === "rascunho").length,
    }),
    [posts]
  );

  const snapFromEvent = (e: MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const y = e.clientY - rect.top;
    const raw = DAY_START + (y / rect.height) * SPAN;
    const snapped = Math.round(raw / 15) * 15;
    const clamped = Math.max(DAY_START, Math.min(DAY_END - 30, snapped));
    return { time: minutesLabel(clamped), top: ((clamped - DAY_START) / SPAN) * COL_H };
  };

  const hours = Array.from({ length: 8 }, (_, i) => 8 + i * 2);

  return (
    <div className="mx-auto max-w-[1240px] animate-fade-up">
      {/* toolbar */}
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2 rounded-xl border border-white/8 bg-ink-900/60 px-3.5 py-2">
          <button className="text-fog-400 transition hover:text-fog-100 cursor-pointer" aria-label="Semana anterior">‹</button>
          <span className="font-display text-sm font-semibold">Semana 9 – 15</span>
          <button className="text-fog-400 transition hover:text-fog-100 cursor-pointer" aria-label="Próxima semana">›</button>
        </div>
        <div className="flex items-center gap-1.5 rounded-xl border border-aqua-500/20 bg-aqua-500/8 px-3 py-2">
          <Zap size={13} className="text-aqua-300" />
          <span className="text-xs text-fog-300">
            Melhores horários detectados: <span className="font-mono font-semibold text-aqua-300">12h</span> e <span className="font-mono font-semibold text-aqua-300">19h</span>
          </span>
        </div>
        {nextPost && nextLabel && (
          <div className="flex items-center gap-1.5 rounded-xl border border-coral-500/25 bg-coral-500/8 px-3 py-2">
            <Clock3 size={13} className="text-coral-300" />
            <span className="text-xs text-fog-300">
              Próxima publicação: <span className="font-mono font-semibold text-coral-300">{nextLabel}</span> · {inLabel}
            </span>
          </div>
        )}
        <span className="hidden items-center gap-1.5 font-mono text-[10px] uppercase tracking-wide text-fog-600 md:flex">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M5 9l-3 3 3 3M9 5l3-3 3 3M15 19l-3 3-3-3M19 9l3 3-3 3M2 12h20M12 2v20" />
          </svg>
          arraste um post para reagendar
        </span>
        <div className="ml-auto flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => setFilter(null)}
            className={cx(
              "rounded-lg px-2.5 py-1.5 text-[11px] font-semibold transition cursor-pointer",
              filter === null ? "bg-fog-100 text-ink-900" : "border border-white/8 text-fog-400 hover:text-fog-100"
            )}
          >
            Todas
          </button>
          {FILTERS.map((pl) => (
            <button
              key={pl}
              onClick={() => setFilter(filter === pl ? null : pl)}
              title={PLATFORMS[pl].name}
              className={cx(
                "grid h-8 w-8 place-items-center rounded-lg border transition cursor-pointer",
                filter === pl ? "border-transparent" : "border-white/8 text-fog-400 hover:text-fog-100"
              )}
              style={filter === pl ? { background: PLATFORMS[pl].tint, color: PLATFORMS[pl].color } : undefined}
            >
              <PlatformIcon platform={pl} size={14} />
            </button>
          ))}
        </div>
      </div>

      {/* grid semanal */}
      <div className="panel overflow-x-auto p-4">
        <div className="min-w-[860px]">
          {/* cabeçalho dos dias */}
          <div className="mb-2 flex pl-14">
            {WEEK.map((w, i) => (
              <div key={w.d} className="flex-1 px-1">
                <div
                  className={cx(
                    "flex items-center justify-center gap-2 rounded-lg border py-2",
                    i === TODAY ? "border-coral-500/40 bg-coral-500/10" : "border-white/6 bg-ink-900/40"
                  )}
                >
                  <span className={cx("font-mono text-[10px] uppercase tracking-widest", i === TODAY ? "text-coral-300" : "text-fog-500")}>{w.d}</span>
                  <span className={cx("font-display text-base font-bold", i === TODAY ? "text-coral-300" : "text-fog-200")}>{w.n}</span>
                  {i === TODAY && <span className="rounded bg-coral-500 px-1.5 py-px font-mono text-[9px] font-bold uppercase text-white">hoje</span>}
                </div>
              </div>
            ))}
          </div>

          <div className="flex">
            {/* régua de horas */}
            <div className="w-14 shrink-0 pr-2" style={{ height: COL_H }}>
              <div className="relative h-full">
                {hours.map((h) => (
                  <span
                    key={h}
                    className="absolute right-2 -translate-y-1/2 font-mono text-[10px] text-fog-600"
                    style={{ top: ((h * 60 - DAY_START) / SPAN) * COL_H }}
                  >
                    {String(h).padStart(2, "0")}h
                  </span>
                ))}
              </div>
            </div>

            {/* colunas */}
            {WEEK.map((_, dayIdx) => {
              const dayPosts = visible.filter((p) => p.day === dayIdx);
              return (
                <div
                  key={dayIdx}
                  className="relative flex-1 cursor-cell rounded-lg border-l border-white/5 px-1 transition-colors hover:bg-white/2"
                  style={{
                    height: COL_H,
                    backgroundImage: "repeating-linear-gradient(to bottom, rgba(140,160,200,0.08) 0, rgba(140,160,200,0.08) 1px, transparent 1px, transparent 40px)",
                  }}
                  onClick={(e) => {
                    const { time } = snapFromEvent(e);
                    onSlotClick(dayIdx, time);
                  }}
                  onMouseMove={(e) => {
                    const { time, top } = snapFromEvent(e);
                    setGhost({ day: dayIdx, time, top });
                  }}
                  onMouseLeave={() => setGhost(null)}
                  onDragOver={(e) => {
                    if (!dragId) return;
                    e.preventDefault();
                    e.dataTransfer.dropEffect = "move";
                    const { time, top } = snapFromEvent(e);
                    setDragSlot({ day: dayIdx, time, top });
                  }}
                  onDrop={(e) => {
                    e.preventDefault();
                    const id = e.dataTransfer.getData("text/plain") || dragId;
                    const { time } = snapFromEvent(e);
                    if (id) onMove(id, dayIdx, time);
                    setDragId(null);
                    setDragSlot(null);
                    setGhost(null);
                  }}
                >
                  {/* linha do agora */}
                  {dayIdx === TODAY && (
                    <div
                      className="pointer-events-none absolute left-0 right-0 z-10 flex items-center"
                      style={{ top: ((nowMin - DAY_START) / SPAN) * COL_H }}
                    >
                      <span className="h-1.5 w-1.5 -translate-x-[3px] rounded-full bg-coral-500" />
                      <span className="h-px flex-1 bg-coral-500/70" />
                      <span className="mr-1 rounded bg-coral-500/15 px-1 font-mono text-[9px] font-semibold text-coral-300">{nowLabel}</span>
                    </div>
                  )}

                  {/* fantasma de reagendamento durante o arrasto */}
                  {dragId && dragSlot && dragSlot.day === dayIdx && (
                    <div
                      className="pointer-events-none absolute inset-x-1 z-30 flex items-center justify-center rounded-lg border-2 border-dashed border-aqua-400/80 bg-aqua-500/12"
                      style={{ top: dragSlot.top, height: 52 }}
                    >
                      <span className="font-mono text-[11px] font-bold text-aqua-300">mover para {dragSlot.time}</span>
                    </div>
                  )}

                  {/* ghost de novo post */}
                  {ghost && !dragId && ghost.day === dayIdx && (
                    <div
                      className="pointer-events-none absolute inset-x-1 z-10 flex items-center justify-center rounded-lg border border-dashed border-coral-500/60 bg-coral-500/8"
                      style={{ top: ghost.top, height: 52 }}
                    >
                      <span className="font-mono text-[11px] font-semibold text-coral-300">+ {ghost.time}</span>
                    </div>
                  )}

                  {dayPosts.map((p) => {
                    const top = ((timeToMinutes(p.time) - DAY_START) / SPAN) * COL_H;
                    const color = PLATFORMS[p.platforms[0]].color;
                    const draggable = p.status !== "publicada";
                    return (
                      <div
                        key={p.id}
                        draggable={draggable}
                        onDragStart={(e) => {
                          if (!draggable) return;
                          e.dataTransfer.setData("text/plain", p.id);
                          e.dataTransfer.effectAllowed = "move";
                          setDragId(p.id);
                        }}
                        onDragEnd={() => {
                          setDragId(null);
                          setDragSlot(null);
                        }}
                        onClick={(e) => e.stopPropagation()}
                        className={cx(
                          "group absolute inset-x-1 z-20 overflow-hidden rounded-lg border bg-ink-800/95 px-2.5 py-2 shadow-md shadow-black/25 transition-all hover:z-30 hover:-translate-y-0.5 hover:shadow-xl hover:shadow-black/40",
                          draggable && "cursor-grab active:cursor-grabbing",
                          dragId === p.id && "scale-[0.97] opacity-35",
                          p.status === "rascunho" ? "border-dashed border-amberx-400/50" : "border-white/8",
                          p.status === "publicada" && "opacity-75 hover:opacity-100"
                        )}
                        style={{ top, height: 56, borderLeftWidth: 3, borderLeftColor: color }}
                      >
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono text-[10px] font-semibold text-fog-300">{p.time}</span>
                          <span className="flex -space-x-0.5">
                            {p.platforms.map((pl) => (
                              <span key={pl} style={{ color: PLATFORMS[pl].color }}>
                                <PlatformIcon platform={pl} size={11} />
                              </span>
                            ))}
                          </span>
                          {p.status === "publicada" && (
                            <span className="ml-auto flex items-center gap-1 font-mono text-[9px] text-aqua-300">
                              <Check size={10} /> {p.engagement ? fmtCompact(p.engagement) : "ok"}
                            </span>
                          )}
                          {p.status === "rascunho" && (
                            <span className="ml-auto rounded bg-amberx-400/15 px-1 font-mono text-[9px] font-semibold uppercase text-amberx-400">rascunho</span>
                          )}
                          <button
                            onClick={() => onDelete(p.id)}
                            className="ml-auto hidden h-5 w-5 place-items-center rounded bg-rose-500/20 text-rose-300 transition hover:bg-rose-500/35 group-hover:grid cursor-pointer"
                            aria-label="Remover publicação"
                          >
                            <X size={11} />
                          </button>
                        </div>
                        <p className="mt-1 line-clamp-2 text-[11px] leading-tight text-fog-200">{p.text}</p>
                        {p.media && (
                          <span className="absolute bottom-1.5 right-2 font-mono text-[9px] uppercase tracking-wide text-fog-500">{p.media}</span>
                        )}
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* rodapé */}
      <div className="mt-3.5 flex flex-wrap items-center gap-x-5 gap-y-2 text-[11px] text-fog-500">
        <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm border border-white/20 bg-ink-700" /> {counts.ag} agendadas</span>
        <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-aqua-500/60" /> {counts.pub} publicadas</span>
        <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm border border-dashed border-amberx-400/70" /> {counts.dr} rascunho</span>
        <span className="ml-auto flex items-center gap-1.5 font-mono"><Clock3 size={12} className="text-aqua-300" /> clique em qualquer horário vazio para compor</span>
      </div>
    </div>
  );
}
