import { useEffect, useMemo, useState } from "react";
import { Check, Download, Trophy } from "lucide-react";
import { AreaChart } from "../components/Charts";
import { PlatformIcon } from "../components/Icons";
import { Delta, SectionHead } from "../components/ui";
import { ACCOUNTS, PLATFORMS, cx, fmtCompact, genSeries } from "../lib/data";

const TOP_POSTS = [
  { text: "Antes e depois do rebrand da @flor.decor", platform: "instagram" as const, reach: 184200, er: 9.4 },
  { text: "Processo de embalagem em 15 segundos", platform: "tiktok" as const, reach: 152800, er: 11.2 },
  { text: "Thread: 5 aprendizados publicando todo dia", platform: "x" as const, reach: 96400, er: 4.8 },
  { text: "Tour completo pelo estúdio novo", platform: "youtube" as const, reach: 61300, er: 6.1 },
];

const DAYS = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"];
const HOURS = [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19];

function heatValue(d: number, h: number): number {
  const lunch = Math.exp(-Math.pow(h - 12, 2) / 2.2) * 0.8;
  const prime = Math.exp(-Math.pow(h - 19, 2) / 1.8);
  const dayFactor = d >= 5 ? 0.72 : 0.85 + (d === 3 ? 0.15 : 0);
  const jitter = ((d * 31 + h * 17) % 10) / 60;
  return Math.min(1, (0.08 + lunch + prime) * dayFactor + jitter);
}

export default function Analytics() {
  const [range, setRange] = useState<7 | 30 | 90>(30);
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 60);
    return () => clearTimeout(t);
  }, []);

  const series = useMemo(
    () => [
      { name: "Alcance", color: "#ff7a5c", data: genSeries(range, 7200, 2400, range + 2) },
      { name: "Engajamento", color: "#45e0ce", data: genSeries(range, 2600, 950, range * 5 + 1) },
    ],
    [range]
  );

  const [exported, setExported] = useState(false);
  const exportCsv = () => {
    const head = "Dia;Alcance;Engajamento";
    const rows = series[0].data.map((v, i) => `${i + 1};${v};${series[1].data[i]}`);
    const blob = new Blob(["\ufeff" + [head, ...rows].join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `pulso-desempenho-${range}d.csv`;
    a.click();
    URL.revokeObjectURL(url);
    setExported(true);
    setTimeout(() => setExported(false), 2600);
  };

  const maxFollowers = Math.max(...ACCOUNTS.map((a) => a.followers));
  const best = useMemo(() => {
    let bd = 0, bh = 19, bv = 0;
    DAYS.forEach((_, d) => HOURS.forEach((h) => {
      const v = heatValue(d, h);
      if (v > bv) { bv = v; bd = d; bh = h; }
    }));
    return { d: bd, h: bh };
  }, []);

  return (
    <div className="mx-auto max-w-[1240px] space-y-5">
      <div className="grid grid-cols-12 gap-5">
        <section className="panel col-span-12 p-5 animate-fade-up xl:col-span-8">
          <div className="mb-1 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="font-display text-base font-semibold tracking-tight">Desempenho consolidado</h3>
              <p className="text-xs text-fog-500">Todas as contas · atualizado há 4 min</p>
            </div>
            <div className="flex items-center gap-2.5">
              <button
                onClick={exportCsv}
                className={cx(
                  "flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-[11px] font-semibold transition active:scale-[0.96] cursor-pointer",
                  exported
                    ? "border-aqua-500/40 bg-aqua-500/12 text-aqua-300"
                    : "border-white/10 text-fog-300 hover:border-coral-500/40 hover:text-coral-300"
                )}
              >
                {exported ? (<><Check size={12} /> CSV baixado</>) : (<><Download size={12} /> Exportar CSV</>)}
              </button>
              <div className="flex items-center gap-1 rounded-lg border border-white/8 bg-ink-900/60 p-1">
                {([7, 30, 90] as const).map((r) => (
                  <button
                    key={r}
                    onClick={() => setRange(r)}
                    className={cx(
                      "rounded-md px-3 py-1 font-mono text-[11px] font-semibold transition cursor-pointer",
                      range === r ? "bg-aqua-500/18 text-aqua-300" : "text-fog-500 hover:text-fog-200"
                    )}
                  >
                    {r} dias
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="mt-2 flex items-center gap-5">
            {series.map((s) => (
              <span key={s.name} className="flex items-center gap-1.5 text-[11px] text-fog-400">
                <span className="h-2 w-2 rounded-full" style={{ background: s.color }} /> {s.name}
              </span>
            ))}
            <span className="ml-auto font-mono text-[10px] text-fog-500">passe o mouse para inspecionar</span>
          </div>
          <div className="mt-2">
            <AreaChart series={series} height={264} labelFor={(i) => `dia ${i + 1} de ${range}`} />
          </div>
        </section>

        <section className="panel col-span-12 p-5 animate-fade-up xl:col-span-4" style={{ animationDelay: "0.08s" }}>
          <SectionHead kicker="Por conta" title="Crescimento" />
          <div className="space-y-4">
            {ACCOUNTS.map((a, i) => (
              <div key={a.id}>
                <div className="mb-1.5 flex items-center gap-2">
                  <span className="grid h-7 w-7 place-items-center rounded-lg" style={{ background: PLATFORMS[a.platform].tint, color: PLATFORMS[a.platform].color }}>
                    <PlatformIcon platform={a.platform} size={13} />
                  </span>
                  <span className="text-[13px] font-semibold text-fog-200">{PLATFORMS[a.platform].name}</span>
                  <span className="ml-auto font-mono text-xs text-fog-300">{fmtCompact(a.followers)}</span>
                  <Delta value={a.growth} />
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-ink-700/60">
                  <div
                    className="h-full rounded-full transition-[width] duration-1000 ease-out"
                    style={{
                      width: mounted ? `${(a.followers / maxFollowers) * 100}%` : "0%",
                      background: `linear-gradient(90deg, ${PLATFORMS[a.platform].color}55, ${PLATFORMS[a.platform].color})`,
                      transitionDelay: `${i * 90}ms`,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      <div className="grid grid-cols-12 gap-5">
        <section className="panel col-span-12 p-5 animate-fade-up xl:col-span-7" style={{ animationDelay: "0.12s" }}>
          <SectionHead
            kicker="Inteligência de horário"
            title="Quando seu público está on-line"
            right={<span className="rounded-lg border border-coral-500/25 bg-coral-500/10 px-2.5 py-1 font-mono text-[10px] font-semibold uppercase tracking-wide text-coral-300">pico: {DAYS[best.d]} {best.h}h</span>}
          />
          <div className="overflow-x-auto">
            <div className="min-w-[520px]">
              <div className="mb-1.5 grid grid-cols-[44px_repeat(12,1fr)] gap-1">
                <span />
                {HOURS.map((h) => (
                  <span key={h} className="text-center font-mono text-[10px] text-fog-600">{h}h</span>
                ))}
              </div>
              {DAYS.map((d, di) => (
                <div key={d} className="mb-1 grid grid-cols-[44px_repeat(12,1fr)] items-center gap-1">
                  <span className="font-mono text-[10px] uppercase text-fog-500">{d}</span>
                  {HOURS.map((h) => {
                    const v = heatValue(di, h);
                    const isBest = di === best.d && h === best.h;
                    return (
                      <div
                        key={h}
                        title={`${d} ${h}h — atividade ${Math.round(v * 100)}%`}
                        className={cx(
                          "h-7 cursor-default rounded-[6px] transition-transform hover:scale-110",
                          isBest && "ring-2 ring-coral-400 ring-offset-1 ring-offset-ink-900"
                        )}
                        style={{ background: `rgba(69,224,206,${0.06 + v * 0.72})` }}
                      />
                    );
                  })}
                </div>
              ))}
              <div className="mt-3 flex items-center gap-2">
                <span className="font-mono text-[10px] uppercase tracking-wide text-fog-500">menos</span>
                {[0.1, 0.25, 0.4, 0.55, 0.7, 0.85].map((v) => (
                  <span key={v} className="h-3 w-6 rounded" style={{ background: `rgba(69,224,206,${v})` }} />
                ))}
                <span className="font-mono text-[10px] uppercase tracking-wide text-fog-500">mais</span>
              </div>
            </div>
          </div>
        </section>

        <section className="panel col-span-12 p-5 animate-fade-up xl:col-span-5" style={{ animationDelay: "0.16s" }}>
          <SectionHead kicker="Ranking" title="Posts com melhor desempenho" />
          <div className="space-y-2.5">
            {TOP_POSTS.map((p, i) => (
              <div key={i} className="group flex items-center gap-3.5 rounded-xl border border-white/6 bg-ink-900/40 p-3 transition hover:border-white/14 hover:bg-ink-900/70">
                <span className={cx(
                  "font-display text-xl font-bold leading-none",
                  i === 0 ? "text-amberx-400" : i === 1 ? "text-fog-300" : i === 2 ? "text-coral-400" : "text-fog-600"
                )}>
                  {i + 1}º
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-medium text-fog-200">{p.text}</p>
                  <p className="mt-0.5 flex items-center gap-1.5 font-mono text-[10px] text-fog-500">
                    <span style={{ color: PLATFORMS[p.platform].color }}><PlatformIcon platform={p.platform} size={11} /></span>
                    alcance {fmtCompact(p.reach)}
                  </p>
                </div>
                <div className="text-right">
                  <p className="flex items-center gap-1 font-mono text-sm font-semibold text-aqua-300"><Trophy size={12} /> {String(p.er).replace(".", ",")}%</p>
                  <p className="font-mono text-[9px] uppercase tracking-wide text-fog-600">engaj.</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
