import { useMemo, useState } from "react";
import { CheckCheck, Inbox as InboxIcon, Send, Sparkles, Timer } from "lucide-react";
import { PlatformIcon } from "../components/Icons";
import { AI_REPLIES, PLATFORMS, cx, type Mention } from "../lib/data";

type Filter = "todas" | "pendentes" | "positivo" | "negativo";

const SENTIMENT: Record<Mention["sentiment"], { label: string; color: string }> = {
  positivo: { label: "Positivo", color: "#45e0ce" },
  neutro: { label: "Neutro", color: "#5aa7f0" },
  negativo: { label: "Negativo", color: "#ff6b5e" },
};

export default function Inbox({ mentions, onReply }: { mentions: Mention[]; onReply: (id: string, text: string) => void }) {
  const [filter, setFilter] = useState<Filter>("todas");
  const [selectedId, setSelectedId] = useState<string>(mentions[0]?.id ?? "");
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [thinking, setThinking] = useState(false);

  const filtered = useMemo(() => {
    switch (filter) {
      case "pendentes": return mentions.filter((m) => !m.replied);
      case "positivo": return mentions.filter((m) => m.sentiment === "positivo");
      case "negativo": return mentions.filter((m) => m.sentiment === "negativo");
      default: return mentions;
    }
  }, [mentions, filter]);

  const selected = mentions.find((m) => m.id === selectedId) ?? filtered[0];
  const pending = mentions.filter((m) => !m.replied).length;

  const filters: { key: Filter; label: string }[] = [
    { key: "todas", label: "Todas" },
    { key: "pendentes", label: `Sem resposta · ${pending}` },
    { key: "positivo", label: "Positivas" },
    { key: "negativo", label: "Negativas" },
  ];

  const suggest = () => {
    if (!selected || thinking) return;
    setThinking(true);
    setTimeout(() => {
      setDrafts((d) => ({ ...d, [selected.id]: AI_REPLIES[selected.sentiment] }));
      setThinking(false);
    }, 900);
  };

  const send = () => {
    if (!selected) return;
    const text = (drafts[selected.id] ?? "").trim();
    if (!text) return;
    onReply(selected.id, text);
    setDrafts((d) => ({ ...d, [selected.id]: "" }));
  };

  return (
    <div className="mx-auto max-w-[1240px] animate-fade-up">
      <div className="mb-4 flex flex-wrap items-center gap-2">
        {filters.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={cx(
              "rounded-lg px-3 py-1.5 text-xs font-semibold transition cursor-pointer",
              filter === f.key ? "bg-fog-100 text-ink-900" : "border border-white/8 text-fog-400 hover:text-fog-100"
            )}
          >
            {f.label}
          </button>
        ))}
        <span className="ml-auto flex items-center gap-1.5 font-mono text-[11px] text-fog-500">
          <Timer size={12} className="text-aqua-300" /> tempo médio de resposta: 12 min
        </span>
      </div>

      <div className="grid grid-cols-12 gap-5">
        {/* lista */}
        <div className="col-span-12 space-y-2.5 lg:col-span-5 xl:col-span-4">
          {filtered.length === 0 && (
            <div className="panel grid place-items-center p-10 text-center">
              <InboxIcon size={28} className="text-fog-600" />
              <p className="mt-3 text-sm text-fog-400">Caixa limpa por aqui.</p>
              <p className="text-xs text-fog-600">Nenhuma menção corresponde a esse filtro.</p>
            </div>
          )}
          {filtered.map((m) => {
            const s = SENTIMENT[m.sentiment];
            const active = selected?.id === m.id;
            return (
              <button
                key={m.id}
                onClick={() => setSelectedId(m.id)}
                className={cx(
                  "panel panel-hover w-full p-3.5 text-left transition cursor-pointer",
                  active && "border-coral-500/40 bg-coral-500/6"
                )}
              >
                <div className="flex items-center gap-2.5">
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full" style={{ background: PLATFORMS[m.platform].tint, color: PLATFORMS[m.platform].color }}>
                    <PlatformIcon platform={m.platform} size={14} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className={cx("truncate text-[13px]", m.unread ? "font-bold text-fog-100" : "font-medium text-fog-300")}>
                      {m.author} <span className="font-mono text-[10px] font-normal text-fog-600">{m.handle}</span>
                    </p>
                    <p className="font-mono text-[10px] text-fog-600">{m.time}</p>
                  </div>
                  {m.unread && !m.replied && <span className="h-2 w-2 shrink-0 rounded-full bg-coral-400" />}
                  {m.replied && (
                    <span className="flex items-center gap-1 rounded-md bg-aqua-500/12 px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase text-aqua-300">
                      <CheckCheck size={10} /> ok
                    </span>
                  )}
                </div>
                <p className={cx("mt-2 line-clamp-2 text-xs leading-snug", m.unread ? "text-fog-200" : "text-fog-400")}>{m.text}</p>
                <span className="mt-2 inline-block rounded-md px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-wide" style={{ background: `${s.color}16`, color: s.color }}>
                  {s.label}
                </span>
              </button>
            );
          })}
        </div>

        {/* detalhe */}
        <div className="col-span-12 lg:col-span-7 xl:col-span-8">
          {selected ? (
            <div className="panel flex h-full flex-col p-5">
              <div className="flex items-center gap-3 border-b border-white/6 pb-4">
                <span className="grid h-11 w-11 place-items-center rounded-full" style={{ background: PLATFORMS[selected.platform].tint, color: PLATFORMS[selected.platform].color }}>
                  <PlatformIcon platform={selected.platform} size={19} />
                </span>
                <div className="flex-1">
                  <p className="font-display text-[15px] font-semibold">{selected.author}</p>
                  <p className="font-mono text-[11px] text-fog-500">{selected.handle} · {selected.time} · via {PLATFORMS[selected.platform].name}</p>
                </div>
                <span
                  className="rounded-lg px-2.5 py-1 font-mono text-[10px] font-semibold uppercase tracking-wide"
                  style={{ background: `${SENTIMENT[selected.sentiment].color}14`, color: SENTIMENT[selected.sentiment].color }}
                >
                  sentimento {SENTIMENT[selected.sentiment].label.toLowerCase()} · {selected.sentiment === "negativo" ? "87%" : selected.sentiment === "positivo" ? "94%" : "71%"}
                </span>
              </div>

              <div className="mt-4 max-w-xl rounded-2xl rounded-tl-md border border-white/8 bg-ink-900/60 px-4 py-3">
                <p className="text-sm leading-relaxed text-fog-200">{selected.text}</p>
              </div>

              {selected.replied && (
                <div className="mt-3 ml-auto max-w-xl rounded-2xl rounded-tr-md border border-aqua-500/25 bg-aqua-500/8 px-4 py-3 animate-fade-up">
                  <p className="mb-1 flex items-center gap-1.5 font-mono text-[9px] font-semibold uppercase tracking-wide text-aqua-300">
                    <CheckCheck size={11} /> resposta enviada
                  </p>
                  <p className="text-sm leading-relaxed text-fog-200">{selected.replied}</p>
                </div>
              )}

              <div className="mt-auto pt-5">
                <label className="mb-1.5 block font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-fog-500">Responder como Lume Studio</label>
                <textarea
                  value={drafts[selected.id] ?? ""}
                  onChange={(e) => setDrafts((d) => ({ ...d, [selected.id]: e.target.value }))}
                  rows={3}
                  placeholder={thinking ? "Escrevendo sugestão…" : "Escreva uma resposta ou peça uma sugestão à IA…"}
                  className="field w-full resize-none px-3.5 py-3 text-sm text-fog-100 placeholder:text-fog-600"
                />
                <div className="mt-3 flex flex-wrap items-center gap-2.5">
                  <button
                    onClick={suggest}
                    disabled={thinking}
                    className="flex items-center gap-2 rounded-lg border border-coral-500/35 bg-coral-500/10 px-3.5 py-2 text-xs font-semibold text-coral-300 transition hover:bg-coral-500/18 disabled:opacity-60 cursor-pointer"
                  >
                    {thinking
                      ? <><Sparkles size={13} className="animate-pulse" /> Pensando…</>
                      : <><Sparkles size={13} /> Sugerir resposta com IA</>}
                  </button>
                  <button
                    onClick={send}
                    disabled={!(drafts[selected.id] ?? "").trim()}
                    className="flex items-center gap-2 rounded-lg bg-aqua-500 px-4 py-2 text-xs font-bold text-ink-950 transition hover:bg-aqua-400 active:scale-[0.97] disabled:cursor-not-allowed disabled:opacity-35 cursor-pointer"
                  >
                    <Send size={13} /> Enviar resposta
                  </button>
                  <span className="ml-auto font-mono text-[10px] text-fog-600">respostas ficam registradas no histórico</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="panel grid h-full place-items-center p-10 text-center">
              <p className="text-sm text-fog-400">Selecione uma menção para responder.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
