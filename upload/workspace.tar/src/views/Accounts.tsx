import { useState } from "react";
import { AlertTriangle, Loader2, Plug, RefreshCw, ShieldCheck } from "lucide-react";
import { PlatformIcon } from "../components/Icons";
import { Delta, SectionHead } from "../components/ui";
import { PLATFORMS, cx, fmtCompact, type Account, type PlatformId } from "../lib/data";

const AVAIL: { platform: PlatformId; desc: string }[] = [
  { platform: "pinterest", desc: "Pins e ideias — ótimo para tráfego de longo prazo" },
  { platform: "whatsapp", desc: "Canal e listas de transmissão da marca" },
];

const STATUS_META: Record<Account["status"], { label: string; color: string }> = {
  online: { label: "Sincronizada", color: "#45e0ce" },
  attention: { label: "Atenção", color: "#ffc857" },
  offline: { label: "Offline", color: "#ff6b5e" },
};

export default function Accounts({
  accounts, onSynced, onConnect,
}: {
  accounts: Account[];
  onSynced: (id: string) => void;
  onConnect: (platform: PlatformId) => void;
}) {
  const [syncing, setSyncing] = useState<string | null>(null);
  const [connecting, setConnecting] = useState<PlatformId | null>(null);

  const totalFollowers = accounts.reduce((acc, a) => acc + a.followers, 0);
  const available = AVAIL.filter((a) => !accounts.some((c) => c.platform === a.platform));

  const sync = (id: string) => {
    if (syncing) return;
    setSyncing(id);
    setTimeout(() => {
      onSynced(id);
      setSyncing(null);
    }, 1300);
  };

  const connect = (p: PlatformId) => {
    if (connecting) return;
    setConnecting(p);
    setTimeout(() => {
      onConnect(p);
      setConnecting(null);
    }, 1400);
  };

  return (
    <div className="mx-auto max-w-[1240px] space-y-6">
      {/* resumo */}
      <div className="stagger grid grid-cols-1 gap-3.5 sm:grid-cols-3">
        <div className="panel flex items-center gap-3.5 p-4">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-aqua-500/12 text-aqua-300"><ShieldCheck size={18} /></span>
          <div>
            <p className="font-display text-xl font-bold leading-none">{accounts.length} contas</p>
            <p className="mt-1 text-[11px] text-fog-500">{accounts.filter((a) => a.status === "online").length} sincronizadas agora</p>
          </div>
        </div>
        <div className="panel flex items-center gap-3.5 p-4">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-coral-500/14 text-coral-300"><Plug size={18} /></span>
          <div>
            <p className="font-display text-xl font-bold leading-none">{fmtCompact(totalFollowers)}</p>
            <p className="mt-1 text-[11px] text-fog-500">audiência somada das contas</p>
          </div>
        </div>
        <div className="panel flex items-center gap-3.5 p-4">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-amberx-400/14 text-amberx-400"><AlertTriangle size={18} /></span>
          <div>
            <p className="font-display text-xl font-bold leading-none">1 pendência</p>
            <p className="mt-1 text-[11px] text-fog-500">token do Facebook expira em 3 dias</p>
          </div>
        </div>
      </div>

      {/* contas conectadas */}
      <section>
        <SectionHead kicker="Conectadas" title="Suas contas" />
        <div className="stagger grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {accounts.map((a) => {
            const meta = STATUS_META[a.status];
            const isSyncing = syncing === a.id;
            return (
              <div key={a.id} className="panel panel-hover group relative overflow-hidden p-5">
                <span className="absolute inset-x-0 top-0 h-[2px]" style={{ background: `linear-gradient(90deg, ${PLATFORMS[a.platform].color}88, transparent 75%)` }} />
                <div className="flex items-start gap-3.5">
                  <div
                    className="grid h-12 w-12 shrink-0 place-items-center rounded-xl transition-transform duration-300 group-hover:scale-105"
                    style={{ background: `linear-gradient(140deg, ${PLATFORMS[a.platform].color}30, ${PLATFORMS[a.platform].color}0d)`, color: PLATFORMS[a.platform].color }}
                  >
                    <PlatformIcon platform={a.platform} size={22} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <p className="font-display text-[15px] font-semibold tracking-tight">{PLATFORMS[a.platform].name}</p>
                      <span className="flex items-center gap-1.5 rounded-md px-2 py-0.5 font-mono text-[9px] font-bold uppercase tracking-wider" style={{ background: `${meta.color}14`, color: meta.color }}>
                        <span className={cx("h-1.5 w-1.5 rounded-full", a.status === "online" && "animate-pulse-dot")} style={{ background: meta.color }} />
                        {meta.label}
                      </span>
                    </div>
                    <p className="truncate font-mono text-[11px] text-fog-500">{a.handle}</p>
                    <div className="mt-2.5 flex items-center gap-2.5">
                      <p className="font-display text-lg font-bold leading-none">{fmtCompact(a.followers)}</p>
                      <span className="text-[10px] text-fog-600">seguidores</span>
                      <Delta value={a.growth} />
                    </div>
                  </div>
                </div>

                {a.statusNote && (
                  <p className="mt-3 flex items-center gap-2 rounded-lg border border-amberx-400/20 bg-amberx-400/8 px-3 py-2 text-[11px] text-amberx-400">
                    <AlertTriangle size={12} /> {a.statusNote}
                  </p>
                )}

                <div className="mt-3.5 flex items-center justify-between border-t border-white/5 pt-3.5">
                  <span className="font-mono text-[10px] text-fog-600">sync {isSyncing ? "em curso…" : a.lastSync} · {a.autos} automações</span>
                  <button
                    onClick={() => sync(a.id)}
                    disabled={isSyncing}
                    className="flex items-center gap-1.5 rounded-lg border border-white/10 px-3 py-1.5 text-[11px] font-semibold text-fog-300 transition hover:border-aqua-500/40 hover:text-aqua-300 disabled:opacity-60 cursor-pointer"
                  >
                    <RefreshCw size={12} className={cx(isSyncing && "animate-spin-slow")} /> {isSyncing ? "Sincronizando" : "Sincronizar"}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* disponíveis */}
      {available.length > 0 && (
        <section>
          <SectionHead kicker="Expandir" title="Disponíveis para conectar" />
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            {available.map((av) => (
              <div key={av.platform} className="panel panel-hover flex items-center gap-4 border-dashed p-5">
                <div
                  className="grid h-12 w-12 shrink-0 place-items-center rounded-xl opacity-80"
                  style={{ background: `${PLATFORMS[av.platform].color}14`, color: PLATFORMS[av.platform].color }}
                >
                  <PlatformIcon platform={av.platform} size={22} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-display text-[15px] font-semibold">{PLATFORMS[av.platform].name}</p>
                  <p className="text-xs text-fog-500">{av.desc}</p>
                </div>
                <button
                  onClick={() => connect(av.platform)}
                  disabled={connecting !== null}
                  className="flex shrink-0 items-center gap-2 rounded-lg bg-fog-100 px-3.5 py-2 text-xs font-bold text-ink-900 transition hover:bg-white active:scale-[0.97] disabled:opacity-50 cursor-pointer"
                >
                  {connecting === av.platform ? (<><Loader2 size={13} className="animate-spin" /> Autorizando…</>) : (<><Plug size={13} /> Conectar</>)}
                </button>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
