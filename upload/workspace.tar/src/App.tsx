import { useCallback, useEffect, useState } from "react";
import confetti from "canvas-confetti";
import Shell, { type ViewKey } from "./components/Shell";
import Composer from "./components/Composer";
import { ToastStack, type Toast } from "./components/ui";
import Overview from "./views/Overview";
import CalendarView from "./views/CalendarView";
import Automations from "./views/Automations";
import Analytics from "./views/Analytics";
import Inbox from "./views/Inbox";
import Accounts from "./views/Accounts";
import {
  ACCOUNTS, AUTOMATIONS, EVENT_POOL, MENTIONS, PLATFORMS, POSTS, RUN_LOG, WEEK,
  type Automation, type FeedEvent, type Mention, type PlatformId, type RunLog, type ScheduledPost,
} from "./lib/data";

function Ambient() {
  return (
    <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
      <div className="absolute inset-0 bg-[radial-gradient(1100px_560px_at_78%_-12%,rgba(255,98,66,0.11),transparent_62%),radial-gradient(900px_520px_at_-8%_28%,rgba(43,200,182,0.09),transparent_58%),radial-gradient(820px_520px_at_45%_112%,rgba(90,167,240,0.08),transparent_62%)]" />
      <div className="dot-grid absolute inset-0 opacity-70" />
      <div className="animate-float-a absolute -top-36 right-[10%] h-[430px] w-[430px] rounded-full bg-coral-500/8 blur-[120px]" />
      <div className="animate-float-b absolute -bottom-36 left-[6%] h-[400px] w-[400px] rounded-full bg-aqua-500/7 blur-[120px]" />
      <div className="noise absolute inset-0 opacity-[0.05]" />
    </div>
  );
}

export default function App() {
  const [view, setView] = useState<ViewKey>("overview");
  const [posts, setPosts] = useState<ScheduledPost[]>(POSTS);
  const [autos, setAutos] = useState<Automation[]>(AUTOMATIONS);
  const [mentions, setMentions] = useState<Mention[]>(MENTIONS);
  const [accounts, setAccounts] = useState(ACCOUNTS);
  const [log, setLog] = useState<RunLog[]>(RUN_LOG);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [composer, setComposer] = useState<{ open: boolean; day: number; time: string }>({ open: false, day: 3, time: "19:00" });

  const [events, setEvents] = useState<FeedEvent[]>(() =>
    EVENT_POOL.slice(0, 6).map((e, i) => ({ ...e, id: i + 1, ts: Date.now() - (i + 1) * 52_000 }))
  );

  /* ---------- helpers ---------- */
  const pushToast = useCallback((title: string, desc?: string, tone: Toast["tone"] = "ok") => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-3), { id, title, desc, tone }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4600);
  }, []);

  const addEvent = useCallback((icon: FeedEvent["icon"], text: string, platform?: PlatformId) => {
    setEvents((prev) => [{ icon, text, platform, id: Date.now(), ts: Date.now() }, ...prev].slice(0, 9));
  }, []);

  /* feed ao vivo */
  useEffect(() => {
    const t = setInterval(() => {
      setEvents((prev) => {
        const pick = EVENT_POOL[Math.floor(Math.random() * EVENT_POOL.length)];
        return [{ ...pick, id: Date.now() + Math.random(), ts: Date.now() }, ...prev].slice(0, 9);
      });
    }, 5200);
    return () => clearInterval(t);
  }, []);

  /* ---------- ações ---------- */
  const openComposer = (day = 3, time = "19:00") => setComposer({ open: true, day, time });

  const handleCompose = (post: ScheduledPost, mode: "agendar" | "rascunho" | "agora") => {
    setPosts((p) => [...p, post]);
    const when = `${WEEK[post.day].d} ${WEEK[post.day].n} às ${post.time}`;
    const redes = post.platforms.map((pl) => PLATFORMS[pl].name).join(", ");
    if (mode === "agendar") {
      pushToast("Publicação agendada", `${when} · ${redes}`);
      addEvent("zap", `Novo post agendado para ${when}`, post.platforms[0]);
    } else if (mode === "rascunho") {
      pushToast("Rascunho salvo", "Disponível na agenda para editar depois.", "info");
    } else {
      confetti({
        particleCount: 150,
        spread: 82,
        startVelocity: 38,
        origin: { x: 0.5, y: 0.72 },
        colors: ["#ff6242", "#45e0ce", "#ffc857", "#f5f8ff"],
        disableForReducedMotion: true,
        ticks: 210,
      });
      pushToast("Publicado agora", `Enviado para ${redes}.`);
      addEvent("share", `Post publicado agora em ${redes}`, post.platforms[0]);
    }
  };

  const movePost = (id: string, day: number, time: string) => {
    setPosts((p) => p.map((x) => (x.id === id ? { ...x, day, time } : x)));
    pushToast("Publicação reagendada", `${WEEK[day].d} ${WEEK[day].n} às ${time}`, "info");
    addEvent("zap", `Post movido para ${WEEK[day].d} às ${time}`);
  };

  const deletePost = (id: string) => {
    setPosts((p) => p.filter((x) => x.id !== id));
    pushToast("Publicação removida da agenda", undefined, "warn");
  };

  const quickSchedule = () => {
    setPosts((p) => [
      ...p,
      { id: `p${Date.now()}`, day: 3, time: "19:00", platforms: ["instagram"], text: "Reel antecipado: processo de embalagem em 15 segundos ⏱", media: "vídeo", status: "agendada" },
    ]);
    pushToast("Reel agendado para hoje, 19h", "Horário escolhido pelo motor de IA com base no pico de audiência.");
    addEvent("zap", "Pulso agendou o reel para o pico das 19h", "instagram");
  };

  const toggleAuto = (id: string) => {
    setAutos((prev) => prev.map((a) => (a.id === id ? { ...a, active: !a.active } : a)));
    const a = autos.find((x) => x.id === id);
    if (a) pushToast(`Automação ${a.active ? "pausada" : "ativada"}`, a.name, a.active ? "warn" : "info");
  };

  const runAuto = (id: string) => {
    const a = autos.find((x) => x.id === id);
    setAutos((prev) => prev.map((x) => (x.id === id ? { ...x, runs: x.runs + 1, lastRun: "agora" } : x)));
    const hh = new Date().toTimeString().slice(0, 5);
    setLog((prev) => [{ id: Date.now(), time: hh, text: `${a?.name ?? "Automação"}: execução manual — 8 ações concluídas`, status: "ok" as const }, ...prev].slice(0, 14));
    pushToast("Automação executada", "8 ações concluídas com sucesso.");
    addEvent("zap", `Execução manual: ${a?.name ?? "automação"} (8 ações)`, a?.platforms[0]);
  };

  const addAuto = (a: Automation) => {
    setAutos((prev) => [a, ...prev]);
    pushToast("Automação ativada", `${a.trigger} → ${a.action}`);
    addEvent("zap", `Nova automação criada: ${a.name}`);
  };

  const replyMention = (id: string, text: string) => {
    const m = mentions.find((x) => x.id === id);
    setMentions((prev) => prev.map((x) => (x.id === id ? { ...x, replied: text, unread: false } : x)));
    pushToast("Resposta enviada", m ? `Para ${m.author} via ${PLATFORMS[m.platform].name}.` : undefined);
    addEvent("comment", `Resposta enviada para ${m?.author ?? "seguidor"}`, m?.platform);
  };

  const syncAccount = (id: string) => {
    const acc = accounts.find((x) => x.id === id);
    setAccounts((prev) => prev.map((x) => (x.id === id ? { ...x, lastSync: "agora" } : x)));
    pushToast("Conta sincronizada", acc ? `${acc.handle} · dados atualizados.` : undefined);
    addEvent("trend", `Sincronização concluída: ${acc?.handle ?? "conta"}`, acc?.platform);
  };

  const connectAccount = (platform: PlatformId) => {
    setAccounts((prev) => [
      ...prev,
      {
        id: `a${Date.now()}`,
        platform,
        handle: "@lumestudio",
        followers: platform === "pinterest" ? 4300 : 2150,
        growth: 0,
        status: "online",
        lastSync: "agora",
        autos: 0,
      },
    ]);
    pushToast(`${PLATFORMS[platform].name} conectada`, "Sincronização inicial concluída.");
    addEvent("user", `${PLATFORMS[platform].name} conectada ao Pulso`, platform);
  };

  const pending = mentions.filter((m) => m.unread && !m.replied).length;

  return (
    <div className="relative h-full font-sans">
      <Ambient />
      <Shell
        view={view}
        setView={setView}
        onNewPost={() => openComposer()}
        pendingMentions={pending}
        posts={posts}
        mentions={mentions}
        autos={autos}
      >
        {view === "overview" && (
          <Overview posts={posts} events={events} onNavigate={setView} onQuickSchedule={quickSchedule} />
        )}
        {view === "agenda" && (
          <CalendarView
            posts={posts}
            onDelete={deletePost}
            onSlotClick={(day, time) => openComposer(day, time)}
            onMove={movePost}
          />
        )}
        {view === "automations" && (
          <Automations autos={autos} log={log} onToggle={toggleAuto} onRun={runAuto} onAdd={addAuto} />
        )}
        {view === "analytics" && <Analytics />}
        {view === "inbox" && <Inbox mentions={mentions} onReply={replyMention} />}
        {view === "accounts" && <Accounts accounts={accounts} onSynced={syncAccount} onConnect={connectAccount} />}
      </Shell>

      <Composer
        open={composer.open}
        day={composer.day}
        time={composer.time}
        onClose={() => setComposer((c) => ({ ...c, open: false }))}
        onSubmit={handleCompose}
      />
      <ToastStack toasts={toasts} dismiss={(id) => setToasts((t) => t.filter((x) => x.id !== id))} />
    </div>
  );
}
